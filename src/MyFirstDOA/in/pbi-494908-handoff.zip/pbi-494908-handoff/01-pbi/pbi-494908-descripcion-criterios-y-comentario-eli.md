# PBI 494908 - Documentación de referencia

Texto copiado tal cual lo compartió el usuario. No se interpretó ni se editó.

---

## Descripción

Implement Product Version Configuration management within the Product Management screen.

Users shall be able to create, edit, view, and remove Configurations associated with a Product Version while the Product Version is in the In Development status.

Configurations define deployment-time values that will be resolved when a Tenant Deployment is performed. As such, Configuration definitions are managed as part of the Product Version, but their actual values are not generated or resolved during Configuration creation.

When a Product Version transitions to Released or Deprecated, all Configuration definitions become read-only and can no longer be modified.

The Value column shows what Value type has been set and what is defined in it (as it works in the Templates Management UI).

Configurations shall be copied when a new Product Version is created using the From Version option.

### Business Rules

- A Product Version may contain zero or more Configurations.
- Configurations can only be created, edited, or removed while the Product Version status is In Development.
- Configurations become read-only when the Product Version status is Released or Deprecated.
- Configurations are loaded when a Product Version is selected.
- Configurations are displayed sorted alphabetically by Key.
- Configurations are copied when a Product Version is created using the From Version option.
- When adding a Configuration the user can select an existing Configuration from a list or add a new one.
- The selected Configuration has the Value fields shown as read-only.
- The new Configuration is added to the Configurations catalog, must follow the Configurations catalog rules.
- Each Configuration contains:
  - Key
  - Value Definition
- Configuration Keys must be unique within a Product Version.
- Configuration Keys are case-insensitive.
- A Configuration Value Definition must be one of:
  - Expression
  - Generated
- For Expression values, it should work as String Interpolation.
  - Example: "ValueDefinition.{{TenantName}}.FromDataSource{{CName}}".
- For Generated values, the user must specify:
  - Encoding Type:
    - Base64
    - Hex
  - Length:
    - 16
    - 32
- For Expression values, the user must select a source from the system-provided list of available data fields.
- Removing a Configuration requires confirmation.
- Configuration values are not generated or resolved during Configuration creation or editing.
- Configuration values shall be generated or resolved only during Tenant Deployment processing (to be addressed in another PBI).

### The UI

- The UI for the Configurations table: `Admin - Product Management - Configurations.jpg`
- Adding a Configuration: `Admin - Product Management - Configurations - Add Configuration.jpg`
- Assigning an existing Configuration, Expression: `Admin - Product Management - Configurations - Add Configuration - Selected existing - Expression.jpg`
- Assigning an existing Configuration, Generated: `Admin - Product Management - Configurations - Add Configuration - Selected existing - Generated.jpg`
- Adding a new Configuration, Expression with list being shown: `Admin - Product Management - Configurations - Add Configuration - Expression - List.jpg`
- Adding a new Configuration, Generated: `Admin - Product Management - Configurations - Add Configuration - Generated.jpg`

---

## Criterios de aceptación

- When a Product Version is selected, all associated Configurations are loaded and displayed in the Configurations table.
- Configurations are displayed sorted alphabetically by Key.
- Users can add Configurations while the Product Version status is In Development.
- Users can select an existing Configuration from the list or add a new one that will be added to the Configurations catalog.
- When creating a Configuration, the user must provide:
  - A unique Key.
  - A Value Definition type.
- The system prevents setting a Configuration when the Key already exists within the Product Version.
- When the selected Value Definition type is Expression, the Configuration is created using a String Interpolation definition.
- The user is provided with a list of available data source fields.
- When the selected Value Definition type is Generated, the user must select:
  - Base64 or Hex.
  - Length 16 or 32.
- Users can remove Configurations while the Product Version status is In Development.
- Before a Configuration is removed, the user is prompted to confirm the action.
- When a Product Version is created using the From Version option, all Configurations from the selected source Product Version are copied to the new Product Version.
- When the Product Version status becomes Released or Deprecated:
  - Configuration creation is disabled.
  - Configuration editing is disabled.
  - Configuration removal is disabled.
  - Existing Configurations remain visible.
- Configuration values are not generated, resolved, or stored during Configuration definition management and are only processed during Tenant Deployment execution.

---

## Comentario de Eli a Leonardo

Hey @Leonardo Santos, Tapajos changed what a Configuration is under the hood, so this one needs a rework:

- 499839 Setting/SettingVersion catalog (additive) - Done: Configurations and Secrets are now Settings in one global catalog. Keys are unique across the catalog, and each definition lives in an append-only revision (editing creates a new revision).
- 499847 ProductVersionSetting linkage entity (supersedes halted 487070) - Done: a Product Version just declares which Settings it requires.
- 499842 Admin UI: Setting management + revision history (supersedes 487075/487076) - Done: the Add/Edit Setting drawer and the "new revision" warning already exist.

Proposed changes:

1. **Assign, don't define.** The table shows the Configurations assigned to the Product Version. Remove means unassign; the Setting stays in the catalog.
2. **Assignment drawer.** It has a searchable dropdown of Configurations not yet assigned to the version, with a + next to it. + opens the existing Add Setting drawer with Configuration preselected; on save, the user returns to the assignment drawer with the new Configuration selected. Edit opens the existing Edit Setting drawer. Only one drawer is ever open (no stacking), and users never have to leave Product Management.
3. **Edits are global.** Editing a Configuration creates a new revision that every Product Version and Template using it picks up on its next deployment. The drawer already warns about this, but I think the AC should say it explicitly.
4. **Release lock applies to assignments.** On Released/Deprecated versions, hide Assign, Unassign and Edit. The definition can still change from other versions or the Settings page.
5. **Value fields match the drawer.** Value Strategy is Expression or Generated (Base64/Hex, 16/32), and the table's Value column follows the Settings page's "Resolution" preview.
6. **Case-insensitive Keys are a good callout.** Today Keys are case-sensitive, so this would be a new backend requirement and not just UI validation.
7. **Mockups.** The existing images already show the dropdown + + pattern, so I think the text here can carry the remaining drawer differences (the Setting fields follow the existing Add/Edit Setting drawer).

For context, the plan is for Product Registration to eventually carry Setting requirements with each version, so long-term this screen becomes the review/correction path. I don't think that changes the scope here, though.

Thoughts?
