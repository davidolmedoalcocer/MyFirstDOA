# Traspaso del PBI 494908: Configurations de una Product Version

Léelo completo antes de tocar nada. Está escrito para otra IA (o persona) que continúe el trabajo sin haber visto la conversación.

## 0. Contenido del paquete

| Carpeta / archivo | Qué contiene |
|---|---|
| `00-LEEME-PRIMERO.md` | Este documento: contexto, estado, problemas, pendientes. |
| `01-pbi/pbi-494908-descripcion-criterios-y-comentario-eli.md` | Descripción, reglas de negocio y criterios de aceptación del PBI, y un comentario de Eli a Leonardo (solo comentario, ver sección 2). |
| `02-estado/reporte-final-pbi-494908.html` | Reporte visual: criterios cumplidos y no cumplidos, archivos modificados con su motivo, decisiones. |
| `03-imagenes/INDICE-IMAGENES.md` y subcarpetas | Mockups del PBI y de otro PBI (494906), capturas del portal real, con su significado. |
| `04-codigo/cambios-rastreados.patch` y `archivos-nuevos.patch` | El código: diff de archivos ya versionados y archivos nuevos completos. Ver sección 7. |
| `05-entorno/COMO-PROBAR-Y-TRUCOS.md` | Cómo ejecutar las pruebas, el entorno y las trampas técnicas. |

## 1. Qué es el PBI

**PBI 494908** (Dev Portal, equipo Neptune): gestión de **Configurations** de una **Product Version** en la pantalla **Product Management** del Admin UI. Una Configuration es un Setting del catálogo global con placement `Config`. La versión solo declara cuáles requiere (entidad `ProductVersionSetting`); quitar una Configuration de una versión **no** la borra del catálogo.

Resumen de lo exigido (texto completo en `01-pbi/`):
- Ver las Configurations de la versión seleccionada, ordenadas por Key, con la columna Value igual que en Templates Management.
- Agregar, editar y quitar **solo** con la versión **In Development**. En Released/Deprecated quedan de solo lectura.
- Al agregar: elegir una existente (campos Value en solo lectura) o crear una nueva en el catálogo (Key única + definición **Expression** con lista de campos, o **Generated** Base64/Hex y 16/32).
- Key única dentro de la versión; las Keys **no distinguen mayúsculas**.
- Quitar pide confirmación.
- Al crear una versión con la opción **From Version**, se copian las Configurations de la versión origen elegida.
- Los valores nunca se generan ni resuelven al definir; eso lo hace el despliegue (otro PBI).

**Stack:** Vue 3 + `@infios/uikit` (web components `infios-*`, obligatorio usarlos), TypeScript, Pinia, vee-validate + yup; backend .NET 10 con OData y EF Core (Postgres); pruebas con Vitest, xUnit y Playwright. Repositorio `/workspaces/dev-portal`, rama `pbi/494908_manage-product-version-configurations`. Código compartido de UI en `sharedUIComponents/`, Admin UI en `adminUi/`, backend en `devPortalService/`, e2e en `e2e/`.

## 2. Cómo trabaja el usuario (respétalo)

- **Responde en español. El código, los comentarios y las pruebas van en inglés.**
- **No asumas ni decidas por tu cuenta.** Si algo no está en el PBI, en las imágenes o no se deduce del código, **pregunta antes de construir**. A la vez, **no preguntes lo que puedes resolver leyendo el código**: el usuario se molestó cuando hice preguntas que debía contestar analizando el repo.
- **Sigue los patrones que ya usa el repo y sé lo menos invasivo posible.** Antes de diseñar algo busca su equivalente (ver sección 6, p. ej. Templates).
- Cuando dice **"no modifiques nada"**, no toques código ni datos; leer sí vale.
- El **comentario de Eli** del archivo `01-pbi` **es solo un comentario, no una decisión adoptada**. Solo cuenta lo que esté en la descripción y los criterios del PBI.
- Esas imágenes con prefijo `pbi-494906` son de **otro PBI**; el usuario las dio como base visual de pantallas que este PBI necesita (menú Add Version, drawer From Version). **No tengo la descripción de ese PBI.**
- Reglas del repo (ya cargadas como reglas del proyecto): usar componentes de `@infios/uikit`, no HTML crudo; registrar los iconos que uses; en e2e, crear y borrar datos con `ApiHelpers` + `cleanup`.
- Sé honesto con los resultados: nunca declares algo "listo" sin haberlo ejecutado. Las pruebas que no pude correr están marcadas abajo.

## 3. Estado frente al PBI

### Cumplido (13)

| Requerimiento | Dónde / cómo |
|---|---|
| Cargar las Configurations al seleccionar la versión, ordenadas por Key | `stores/productManagement.ts` (`fetchConfigurations`) |
| Columna Value igual que Templates | `ProductConfigurationsTabPanel.vue` usa `formatSettingResolution` |
| Agregar solo en In Development | `canEditVersion` en `ProductManagementDashboard.vue`; el backend responde 422 en otros estados |
| Elegir una existente, con la definición en solo lectura | `ProductAssignConfigurationDrawer.vue` + `ProductSettingDefinition.vue` |
| Crear una nueva en el catálogo (Key + Expression/Generated) | `ProductAddConfigurationDrawer.vue`; la guarda `ProductAssignConfigurationDrawer.vue` (`onCreate`) con `createSettingWithInitialVersion`, placement Config |
| Expression como interpolación, con lista de campos | Al escribir `{{` se muestra la lista (`getDataSourceOptions`); el texto se guarda tal cual |
| Generated: Base64/Hex y 16/32 | Mismo formulario |
| Key repetida en la versión se impide | El selector oculta las ya asignadas; el backend responde 409; una Key repetida en el catálogo se rechaza y se muestra el motivo |
| Quitar con la versión In Development | Botón de papelera por fila (`ProductConfigurationsTabPanel.vue`) → drawer en modo `Remove` → `DELETE /productVersionSettings(id)` |
| Confirmación antes de quitar | El drawer `Remove Configuration` (Key en solo lectura, Cancel y Remove rojo) |
| From Version copia las Configurations de la versión elegida | Menú Add Version + `ProductVersionDrawer.vue` + backend `CreateFromVersion` |
| Released/Deprecated: crear y quitar deshabilitados; las existentes se ven | Botones deshabilitados fuera de In Development; el backend rechaza con 422 |
| Los valores no se generan al definir | Solo se guarda la definición |

### NO cumplido (2): **no está todo hecho**

1. **Editar una Configuration.** La descripción dice "create, edit, view, and remove" y la regla "se pueden crear, editar o quitar solo en In Development". No existe ninguna acción de editar. El backend expone PUT/PATCH sobre `ProductVersionSetting`. **No se definió qué se edita** (la Key, la definición, o nada, porque la definición pertenece al catálogo). Preguntar al usuario.
2. **Keys sin distinguir mayúsculas.** El backend compara con `==` (`SettingService`) y el índice único es sensible a mayúsculas (`SettingConfiguration`). Hoy se pueden crear `ABC` y `abc`. Requiere cambio de backend y quizá migración. Preguntar el alcance antes.

## 4. Qué se construyó y cómo funciona

### 4.1 Alta de una Configuration nueva (botón +)
- `ProductAssignConfigurationDrawer.vue` es el panel "Assign Configuration". Su botón **+** abre `ProductAddConfigurationDrawer.vue` (apilado encima).
- Al enviar, `onCreate` llama a `createSettingWithInitialVersion` (POST `/admin/odata/settings/createWithInitialVersion`, el mismo que usa el catálogo) con `manifestPlacement: Config`. Si Expression, `valueExpression` es el texto tal cual; si Generated, `generatedFormat` y `generatedLength` numérico.
- Si el servidor acepta: recarga la lista, **selecciona la Key nueva** y cierra el formulario. Si rechaza: el formulario sigue abierto con lo escrito y muestra el motivo (`refusalMessage` entiende texto plano, `{message}` y `{error:{message}}`).
- La lista de campos para `{{` viene de `DataSourceOptions.AllowedValues` (lista fija en `devPortalService/src/Domain/Models/DataSourceOptions.cs`, expuesta por `GET Templates/getDataSourceOptions`). El backend valida cada `{{token}}` contra esa lista (`SettingVersionExpressionParser`). Al desplegar, `DeploymentFieldLookup` es un marcador que devuelve `stub-{campo}`.

### 4.2 Quitar una Configuration
- Patrón copiado de `TemplateConfigTabPanel.vue` + `TemplateConfigDrawer.vue`: un solo drawer con `mode`, aquí `'Add' | 'Remove'`.
- Respuestas del usuario: si falla, aviso emergente genérico **"Update failed"** (sin motivo, como Templates); si funciona, el drawer se cierra **sin aviso** y la tabla se recarga.
- El store lanza el error (`removeConfiguration`) y el panel lo captura; es una diferencia consciente con Templates, que lo captura en el store.

### 4.3 From Version
- **Backend** (copiado de `TemplatesController.Post` + `TemplateService.CreateFromTemplate`): `ProductVersionDto` tiene `Guid? SourceProductVersionId` (solo de solicitud, no se guarda, ignorado en `DtoMapper`). `ProductVersionsController.Post` bifurca a `IProductVersionService.CreateFromVersion`. `ProductVersionService.CreateFromVersion` valida que el origen exista, sea del mismo producto y no esté Removed (si no, 422) y reutiliza la creación con su transacción; la copia de los `SettingId` la hace `ProductVersionSettingService.CopyFromVersionAsync` (comparte código con el copy-forward). **Sin origen, el comportamiento anterior no cambió**: una versión nueva copia de la versión anterior (PBI 499846/509996).
- **Frontend** (copiado de `TemplateDashboard.vue` + `TemplateDrawer.vue`): el botón Add Version, que no hacía nada, pasó a ser un `infios-dropdown` con *New Version* (deshabilitado, es del PBI 494906) y *From Version* (deshabilitado si el producto no tiene versiones). `ProductVersionDrawer.vue` (modo `fromVersion`) pide Version `X.Y.Z` y la versión origen. Éxito: aviso "Version created successfully" y la versión nueva queda seleccionada; fallo: "Failed to create version" y el drawer sigue abierto.

## 5. Decisiones mías que el usuario aún no ha confirmado explícitamente

Pregunta antes de darlas por buenas si te piden cambiarlas:
1. La Key recién creada queda **seleccionada** en Select Key (el usuario pidió "disponible").
2. Submit del alta exige texto en la expresión; la Key y la expresión se **recortan** (`trim`). Choca con "guardar tal como se escribió" en los bordes.
3. La lista de campos se filtra por "contiene" y se ordena alfabéticamente.
4. Cancel del alta se deshabilita mientras guarda; el formulario no valida los `{{campos}}` en el cliente (lo hace el servidor).
5. From Version: el selector de origen **no** viene preseleccionado (la imagen muestra 1.0.0 elegida; no se sabe si es preselección). Copia **todos** los Settings del origen (también Secrets), como la copia automática y como Templates. Puede ser un origen Released/Deprecated.
6. En el drawer de versión se valida en cliente que la versión no exista ya; el servidor responde 409 como última barrera.
7. Por el comentario de Eli (no adoptado), el PBI podría querer que el + reutilice el drawer Add Setting del catálogo sin apilar; yo construí un formulario propio, que es lo que muestran las imágenes del PBI.

## 6. Patrones del repo que usé (úsalos igual)

- **Un drawer por entidad con prop `mode`:** `TemplateDrawer` (`'new' | 'fromTemplate' | 'fromTenant' | 'edit'`), `TemplateConfigDrawer` (`'Add' | 'Remove'`), `SettingDrawer` (`'Add' | 'Edit'`).
- **Menú Add con opciones New/From:** `TemplateDashboard.vue` y `TenantDashboard.vue` (`infios-dropdown` + `infios-menu-item`).
- **Crear desde un origen:** DTO con `Source*Id` opcional, ignorado en `DtoMapper`, y el controlador bifurca a un método de servicio `CreateFrom…` (`TemplatesController`).
- **Acción por fila con papelera:** `rowActionsRenderer` con `InfiosIconButton name="trash-can"`.
- **Confirmación de borrado:** drawer en modo Remove (Templates) o `ConfirmationDialog.vue` (catálogo de Settings, que además consulta `checkSettingHasReferences`).
- **Errores y avisos:** `useToast()`; `utils.odataErrorMessage` para el sobre OData.
- **Deshabilitar un menú:** `disabled` sobre `infios-dropdown`.

## 7. Problemas conocidos

1. **Prueba e2e intermitente (sin causa identificada).** `ProductManagement.test.ts`: "Add Configuration from + saves the key to the catalog, and it can be picked with the same definition after a reload". Falla a veces en `selectAssignConfigurationKey` (en el page object): tras recargar, no encuentra la Key recién creada en Select Key en 5 s. Vi 1 fallo en 6 corridas con 2 procesos y más con todos en paralelo; sola pasó 6 de 6; un bucle de 25 recargas con un Setting creado por API pasó 25 de 25. En una captura de un fallo la Key sí aparecía en la lista. Ya fallaba antes de añadir From Version. Pista a investigar: algo específico de crear las Keys por la UI justo antes de recargar.
2. **Released/Deprecated no se probó en el navegador:** el botón de quitar deshabilitado solo tiene pruebas unitarias; el backend sí está probado.
3. **Las pruebas Playwright se corrieron contra el stack de desarrollo con proxies,** no con la tarea Docker oficial del README.
4. **Sin comparación píxel a píxel** con los mockups; solo estructural.

## 8. Qué falta

1. **Editar una Configuration** (definir con el usuario qué se edita) y que se deshabilite fuera de In Development.
2. **Keys sin distinguir mayúsculas** (backend + posible migración + pruebas).
3. Investigar la prueba intermitente (sección 7.1).
4. Probar en navegador una versión Released/Deprecated (se necesita crear un Build y liberar la versión, o forzar el estado).
5. Confirmar con el usuario las decisiones de la sección 5.
6. Si el usuario lo pide: la entrada *New Version* del menú y el drawer con Arguments pertenecen al PBI 494906. El backend aún no tiene `Arguments` (lo agregaría el AB#509995, que prevé una propiedad persistida `CopyFromProductVersionId`; mi campo `SourceProductVersionId` es solo de solicitud y no choca, pero hay que avisarles).
7. Commits: nada está commiteado. Convenciones del proyecto: ramas, `[AB#494908]` en el título del PR y `Closes AB#494908`, ver `.kiro/steering` (reglas de ADO, PR y ramas).

## 9. Resultados de pruebas al momento del traspaso

| Conjunto | Resultado |
|---|---|
| Backend (`dotnet test`) | 1787 pasan, 15 omitidas (ya estaban omitidas), 0 fallan |
| Frontend (`vitest`) | 1070 pasan en 81 archivos, 0 fallan |
| `vue-tsc` | Sin errores en los archivos del PBI (hay errores previos en otros archivos de prueba) |
| Playwright Product Management | 10 pruebas; pasan todas salvo la intermitente de la sección 7.1 |

## 10. Lista de archivos del PBI y quién los hizo

`git status` al momento del traspaso lista 41 archivos. **Los marcados "mío" los modifiqué yo en esta conversación; los demás ya estaban sin commit al empezar y no sé quién los escribió.** Las rutas son relativas a `/workspaces/dev-portal`.

**Backend (todos míos):** `devPortalService/src/Dto/ProductVersionDto.cs`, `src/Api/Mappings/DtoMapper.cs`, `src/Api/Controllers/OData/ProductVersionsController.cs`, `src/Api/Constants/ProductBuildDocs.cs`, `src/Domain/Services/Interfaces/IProductVersionService.cs`, `src/Domain/Services/Interfaces/IProductVersionSettingService.cs`, `src/Domain.Services/ProductVersionService.cs`, `src/Domain.Services/ProductVersionSettingService.cs`; pruebas en `test/Domain.Services.Test/ProductVersionServiceTests.cs`, `ProductVersionSettingServiceTests.cs` y `test/Api.Test/Controllers/OData/ProductVersionsControllerTests.cs`.

**Frontend (`sharedUIComponents/src`):**
- Míos, nuevos: `components/ProductAddConfigurationDrawer.vue`, `components/ProductVersionDrawer.vue`, `components/__tests__/ProductAddConfigurationDrawer.spec.ts`, `components/__tests__/ProductVersionDrawer.spec.ts`.
- Míos, sobre archivos que ya existían: `components/ProductAssignConfigurationDrawer.vue`, `components/ProductConfigurationsTabPanel.vue`, `components/ProductManagementDashboard.vue`, `stores/productManagement.ts`, `services/productVersionSettingService.ts`, `services/productVersionService.ts` y sus pruebas (`components/__tests__/ProductAssignConfigurationDrawer.spec.ts`, `ProductTabPanels.spec.ts`, `ProductManagementDashboard.spec.ts`, `stores/__tests__/productManagement.spec.ts`, `services/__tests__/productVersionSettingService.spec.ts`, `productVersionService.spec.ts`).
- Ya existían y no los toqué: `components/ProductSettingDefinition.vue`, `models/productVersionSetting.ts`, `services/odataPaging.ts` (y su prueba), cambios en `models/*`, `services/index.ts` y `mocks/productManagementMockData.ts`.

**E2E:** míos `e2e/ui/tests/adminUi/ProductManagement.test.ts`, `e2e/ui/src/pages/ProductManagementPage.wrapper.ts` y el método `deleteSettingByKeyAfterTest` en `e2e/ui/src/utils/ApiHelpers.ts`. Ya existían: el resto de cambios de `ApiHelpers.ts`, `e2e/ui/src/pages/index.ts` y `e2e/api/tests/ProductVersionSettings.test.ts`.

Nota: el parche incluye **todo** el árbol de trabajo (también lo que no es mío). Aplicarlo sobre `43cc0110` reproduce el estado exacto: `git apply 04-codigo/cambios-rastreados.patch` y luego `git apply 04-codigo/archivos-nuevos.patch`.
