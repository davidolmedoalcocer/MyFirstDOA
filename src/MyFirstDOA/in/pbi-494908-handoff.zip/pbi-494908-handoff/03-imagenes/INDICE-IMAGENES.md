# Índice de imágenes

Cada archivo se identificó por su contenido (revisión visual y, para las de 494906 y las de asignación, también por análisis de píxeles). No te fíes del orden en que un visor muestre las imágenes: usa estos nombres.

## `pbi-494908/` (mockups de ESTE PBI, 1400x898)

| Archivo | Qué muestra | Para qué requerimiento sirve |
|---|---|---|
| `pbi-494908-configurations-table.jpg` | Pantalla Product Management con la versión 1.1.0 (In Development) y la pestaña Configurations vacía. Columnas **Key** (con orden) y **Value**; botón **Add Configuration +** arriba a la derecha; botón **Remove** (de la versión) arriba a la derecha; paginación. | Tabla de Configurations ordenada por Key. Botón Add Configuration. |
| `pbi-494908-assign-configuration.jpg` | Drawer **Assign Configuration** recién abierto: campo **\* Key** con un selector "Select Key" y un botón **+** a su derecha; grupo **Value** con radios Expression/Generated (Expression marcado) y el texto de la definición vacío; botones Cancel y Submit. | Elegir una Configuration existente (selector) o crear una nueva (botón +). |
| `pbi-494908-assign-expression.jpg` | El mismo drawer con la Key `AlreadyExistingExpression` elegida. La definición se muestra de solo lectura: `Value.{{TenantName}}.Defined.{{CName}}`. | "La Configuration elegida muestra sus campos Value como solo lectura" (Expression). |
| `pbi-494908-assign-generated.jpg` | El mismo drawer con `AlreadyExistingGenerated`: Generated marcado, Type = Base64, Length = 32, todo de solo lectura. | Lo mismo para Generated. |
| `pbi-494908-add-expression.jpg` | Drawer **Add Configuration** (crear una nueva): **\* Key** con `NewExpressionConfiguration`; grupo **Value** con Expression marcado; el campo de texto contiene `{{` y debajo se despliega la lista de campos (ClusterFQDN, ClusterName, CName, EnvDescription, Environment…). | Crear una Configuration con Expression y lista de campos al escribir `{{`. |
| `pbi-494908-add-generated.jpg` | Drawer **Add Configuration** con `NewGeneratedConfiguration`; Generated marcado; cuadros **Type** (Base64 marcado, Hex) y **Length** (16 marcado, 32). | Crear una Configuration con Generated. |

## `pbi-494906/` (mockups de OTRO PBI, usados como base para "From Version")

El usuario indicó que pertenecen al PBI 494906 y que se pueden tomar como base de las pantallas que este PBI necesita. **No tengo la descripción ni los criterios de aceptación del 494906**: solo estas imágenes.

| Archivo | Qué muestra | Relación con 494908 |
|---|---|---|
| `pbi-494906-add-version.jpg` | Menú **Add Version** abierto con *New Version* y *From Version*; *From Version* aparece **deshabilitada** (producto sin versiones, tabla vacía). | **Sí:** entrada de From Version y su estado deshabilitado. |
| `pbi-494906-add-version2.jpg` | El mismo menú con *From Version* **habilitada** (el producto ya tiene la versión 1.0.0, Deprecated). | **Sí.** |
| `pbi-494906-add-from-version.jpg` | Drawer **Add Version** en modo copia: **\* Version** (texto), el texto "Select existing Version to copy from:", **\* Version** (selector, muestra 1.0.0), Cancel y **Add Version**. | **Sí:** la pantalla de From Version. |
| `pbi-494906-add-new-version.jpg` | Drawer **Add Version** de versión nueva: **\* Version** y **Arguments**. | Solo como base visual: es la creación normal (PBI 494906). Los Arguments no existen todavía en el backend. |
| `pbi-494906-release-version.jpg` | Diálogo "Release Version" (Cancel / Release). | No. Ciclo de vida de la versión. |
| `pbi-494906-deprecated-version.jpg` | Diálogo "Deprecate Version" (Cancel / Deprecate). | No. |
| `pbi-494906-remove-version.jpg` | Diálogo "Remove Version" (Keep / Remove). | No. |

## `capturas-del-portal-real/`

Capturas tomadas por mí del portal de desarrollo con lo implementado.

| Archivo | Qué muestra |
|---|---|
| `shot-menu.png` | Menú Add Version real: *New Version* deshabilitada y *From Version* habilitada. |
| `shot-drawer.png` | Drawer Add Version real, con Version `2.0.0` y el origen `1.0.0` elegido. |

No se comparó píxel a píxel con los mockups; coincide en estructura (título, campos, textos y botones).
