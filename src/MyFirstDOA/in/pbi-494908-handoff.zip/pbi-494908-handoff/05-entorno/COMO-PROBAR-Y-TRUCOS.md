# Cómo probar y trucos técnicos

Todo lo de la sección 1 describe el entorno donde trabajé (un sandbox dentro de un dev container). Puede no ser igual en el tuyo; verifícalo antes de repetirlo.

## 1. Entorno y comandos

**Repositorio:** `/workspaces/dev-portal`. Rama `pbi/494908_manage-product-version-configurations`, HEAD `43cc0110`. Todos los cambios están **sin commit**.

**Stack de desarrollo (contenedores Docker):**

| Contenedor | Puerto en el host | Qué corre |
|---|---|---|
| `dev-portal-admin-ui` | 35001 → 80 | Vite (`pnpm dev --host`) con recarga en caliente. Ruta base `/devportal/adminui`. Lee el código desde un volumen `/app/dev-portal`. |
| `dev-portal-service` | 35000 → 8080 | API .NET con `dotnet watch run` (aplica los cambios de C# solos). Rutas OData de admin: `/admin/odata/...` |
| `dev-portal-postgres-db` | 5432 | Base de datos del stack de desarrollo |

El stack de **testing** (puertos 8080, 8081, 8083) usa imágenes compiladas que **no** incluyen estos cambios. No lo usé.

**Frontend** (`/workspaces/dev-portal/sharedUIComponents`):
```
npx vitest run                    # suite completa: 1070 pruebas, 81 archivos
npx vue-tsc --noEmit              # tipos (hay errores previos en otros archivos de prueba; filtra por los archivos del PBI)
```

**Backend** (`/workspaces/dev-portal/devPortalService`): en el sandbox el directorio `src/obj` no era escribible, así que compilé en una copia:
```
rsync -a --delete --exclude obj --exclude bin /workspaces/dev-portal/devPortalService/ /tmp/dpbuild/
cd /tmp/dpbuild && dotnet test test/DevPortalService.Tests.csproj -v q     # 1787 pasan, 15 omitidas
```
En un entorno normal basta `dotnet test` en `devPortalService`.

**Playwright (admin-ui)** (`/workspaces/dev-portal/e2e`). La forma oficial es la tarea "E2E: Run Tests" (Docker), descrita en `e2e/README.md`. Yo las corrí contra el stack de desarrollo, así:
```
BASE_URL=localhost ADMIN_PORT=35001 API_PORT=35000 PROTOCOL=http \
  npx playwright test --project=admin-ui ProductManagement --reporter=list
```
Para que eso funcione en el sandbox tuve que:
1. `npx playwright install chromium`.
2. Abrir proxies hacia los contenedores, porque `localhost:35000/35001` no era alcanzable: `socat TCP-LISTEN:35000,fork,reuseaddr TCP:<IP del contenedor service>:8080` y lo mismo para 35001 → `<IP del admin-ui>:80`. Las IPs eran `172.18.0.5` y `172.18.0.6`; se consultan con `docker inspect`.
3. Descargar a mano las librerías del sistema que le faltaban al navegador (no había root) y exportar `LD_LIBRARY_PATH`. Si tienes permisos, usa `npx playwright install-deps`.

**Reglas del repositorio para pruebas e2e** (están en `e2e/README.md`): UI tests importan `test` de `ui/src/fixtures/UiFixture`; los datos se crean por API con `ApiHelpers` y se borran con el fixture `cleanup` (nunca en `afterEach`); claves y nombres con sufijo aleatorio; filtros OData con `odataString()`; el ID del PBI va en el título de la prueba.

## 2. Trucos y trampas que ya me costaron tiempo

1. **`infios-search` y atributos booleanos.** Vue ponía `hide-results="false"` como atributo, y para el componente cualquier atributo presente cuenta como `true`; la lista nunca se abría. Solución: `:hideResults.prop="..."` (con camelCase).
2. **`infios-search` abre su lista con eventos de teclado.** `locator.fill()` de Playwright no la abre; usa `pressSequentially()`.
3. **`disabled` de un menú desplegable va en `infios-dropdown`**, no en el botón `slot="trigger"`. En el navegador el botón no recibía el estado. Así lo hacen `ProductTabPanel.vue` y `TenantDashboard.vue`.
4. **Acciones de fila de `InfiosTable`:** solo se pintan para la fila bajo el cursor (`.row-actions-overlay`). En Playwright hay que hacer `hover` en la fila antes de buscar el botón (ver `getRemoveConfigurationButton` en el page object).
5. **`infios-form-field readonly`** sustituye el control por texto; no puedes comprobar `disabled` sobre el `infios-select` interno.
6. **vee-validate en pruebas unitarias:** valida el esquema con un retardo (~5 ms). `flushPromises()` no basta; hace falta esperar un temporizador real. Un campo de texto valida con `change`/`blur` (no con `input`), y el `infios-select` conectado a mano usa `infios-input`/`infios-blur`.
7. **Formas distintas de error del backend:** texto plano (409 desde los controladores base), `{ "code", "message" }` plano (400 de Settings), `{ "error": { "message" } }` (envoltura OData) y ProblemDetails `{ "title", "status", "detail" }` (middleware global, p. ej. el 422 de From Version). `refusalMessage` en `ProductAssignConfigurationDrawer.vue` cubre las tres primeras; **no** cubre `detail`.
8. **Cliente HTTP:** `sharedUIComponents/src/api/httpClient.ts` aborta las peticiones a los 5 s por defecto.
9. **Vite y archivos nuevos:** si creas un archivo en la misma operación que editas a quien lo importa, Vite puede analizar el importador antes de que exista el archivo y mostrar "Failed to resolve import". Crea primero el archivo nuevo y luego edita el importador.
10. **Pruebas unitarias con `vi.mock('../../services')`** (automock): cualquier función nueva exportada por `services` queda mockeada automáticamente.
11. **Iconos:** el Admin UI registra todos los iconos (`adminUi/src/main.ts`), así que `plus`, `content-copy` y `trash-can` ya están disponibles.
12. **Datos de prueba:** tras cada corrida comprobé con `GET /admin/odata/Settings?$filter=startswith(key,'e2e.')` y lo mismo en `Products` que no quedara nada.
