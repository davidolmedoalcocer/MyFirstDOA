#!/usr/bin/env bash
# =============================================================================
# Infios Dev Portal - Case 06 (Dozzle /data persistence) - AFTER, read-only demo
#
# Reads the CORRECTED docker-compose-dozzle.yml from the working tree and shows, with
# its real line numbers, that dozzle_data:/data is mounted in the k1-dozzle service and
# that dozzle_data is declared as a named volume.
#
# Read-only by design: it only runs git (diff/show, read-only flags), grep, sed, awk
# and printf. It does not call Docker, does not create temporary files and writes nothing.
# It does NOT repeat the functional persistence test; it only verifies configuration.
# Exit code: 0 = every check gave the expected result, 1 = at least one did not.
# =============================================================================
set -uo pipefail

REPO="${REPO:-/workspaces/dev-portal}"
FILE="docker-compose-dozzle.yml"
TASK=".workspaceScripts/task_dozzle.sh"
BAD=0

say()  { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
note() { printf '    %s\n' "$*"; }
code() { sed 's/^/      | /'; }
result() {  # result <PASS|FAIL> <check> <detail>
  local c='1;32'; [ "$1" = PASS ] || { c='1;31'; BAD=$((BAD + 1)); }
  printf "    \033[${c}m%-5s\033[0m %s (%s)\n" "$1" "$2" "$3"
}
rgit() { git --no-optional-locks -C "$REPO" "$@"; }   # never refreshes the index

say "Step 0: source of the configuration"
[ -r "$REPO/$FILE" ] || { result FAIL "read $FILE from the working tree" "file not readable"; exit 1; }
YML="$(< "$REPO/$FILE")"
note "Branch: $(rgit branch --show-current)   HEAD: $(rgit rev-parse --short HEAD)"
note "File: $FILE in the working tree (with the fix):"
printf '%s\n' "$YML" | cat -n | code

say "Step 1: the /data mount in the k1-dozzle service"
# Lines of the service-level 'volumes:' list (4-space key, 6-space '- ' items) until the next key.
MOUNTS="$(printf '%s\n' "$YML" | awk '/^  k1-dozzle:/{s=1} s && /^    volumes:/{v=1; next} v && /^      - /{print NR": "$0; next} v && /^    [a-z]/{v=0}')"
note "Service volume entries of k1-dozzle (line: text):"
printf '%s\n' "${MOUNTS:-none}" | code
DATA="$(printf '%s\n' "$MOUNTS" | grep -E '^[0-9]+:       - "dozzle_data:/data"$')"
[ -n "$DATA" ] && result PASS "k1-dozzle mounts dozzle_data on /data" "line ${DATA%%:*}" \
  || result FAIL "k1-dozzle mounts dozzle_data on /data" "entry not found in the service volumes list"
SOCK="$(printf '%s\n' "$MOUNTS" | grep -F '"/var/run/docker.sock:/var/run/docker.sock"')"
[ -n "$SOCK" ] && result PASS "Docker socket mount kept" "line ${SOCK%%:*}" \
  || result FAIL "Docker socket mount kept" "not found"

say "Step 2: the named volume declaration"
TOP="$(printf '%s\n' "$YML" | awk '/^volumes:/{t=1; print NR": "$0; next} t && /^  [a-z_]+:/{print NR": "$0; next} t && /^[^ #]/{t=0}')"
note "Top-level volumes block (line: text):"
printf '%s\n' "${TOP:-none}" | code
printf '%s\n' "$TOP" | grep -q -E '^[0-9]+: volumes:$' && printf '%s\n' "$TOP" | grep -q -E '^[0-9]+:   dozzle_data:$' \
  && result PASS "dozzle_data is declared under top-level volumes:" "$(printf '%s\n' "$TOP" | tail -1 | cut -d: -f1)" \
  || result FAIL "dozzle_data is declared under top-level volumes:" "declaration not found"
note "In project dev-portal (.env:1) Compose names this volume dev-portal_dozzle_data."

say "Step 3: nothing else changed"
note "git diff HEAD -- $FILE:"
DIFF="$(rgit diff HEAD -- "$FILE")"
printf '%s\n' "$DIFF" | code
ADDED="$(printf '%s\n' "$DIFF" | grep -c -E '^\+[^+]')"; REMOVED="$(printf '%s\n' "$DIFF" | grep -c -E '^-[^-]')"
[ "$REMOVED" -eq 0 ] && [ "$ADDED" -gt 0 ] && result PASS "the fix only adds lines" "+$ADDED / -$REMOVED" \
  || result FAIL "the fix only adds lines" "+$ADDED / -$REMOVED"
PORT="$(printf '%s\n' "$YML" | grep -n -F '"8888:8080"')"
[ -n "$PORT" ] && result PASS "published port unchanged" "line ${PORT%%:*}: 8888:8080" || result FAIL "published port unchanged" "not found"

say "Step 4: why the volume survives the task"
DOWN="$(grep -n 'down' "$REPO/$TASK" | head -1)"
note "$TASK:${DOWN%%:*}  ${DOWN#*:}"
if [ -n "$DOWN" ] && ! printf '%s\n' "$DOWN" | grep -q -E -- ' -v( |$)|--volumes'; then
  result PASS "the task's down keeps named volumes" "line ${DOWN%%:*} has no -v / --volumes"
else result FAIL "the task's down keeps named volumes" "${DOWN:-down line not found}"; fi

say "Historical functional test (NOT re-run by this script)"
note "Before the incident, the earlier AFTER demo started this configuration in a temporary project,"
note "stored a test webhook destination and repeated the task's down/up cycle. Recorded:"
note "  /data mounted: PASS (named volume) | dataPersisted: true | test setting survives down/up: PASS"
note "  Dozzle lists containers: PASS | Dozzle streams logs: PASS"
note "That demo was retired after the incident. This script only verifies the configuration."

say "Result"
if [ "$BAD" -eq 0 ]; then
  printf '\n\033[1;32mAFTER RESULT: dozzle_data:/data is mounted in k1-dozzle and dozzle_data is declared as a named\n'
  printf 'volume; the task'"'"'s down does not remove it. Configuration verified (no functional re-run).\033[0m\n'; exit 0
fi
printf '\n\033[1;31mAFTER RESULT: %d check(s) did not give the expected result (see above).\033[0m\n' "$BAD"; exit 1
