#!/usr/bin/env bash
# =============================================================================
# Infios Dev Portal - Case 06 (Dozzle /data persistence) - BEFORE, read-only demo
#
# Reads the ORIGINAL docker-compose-dozzle.yml from Git (HEAD) and shows, with its
# real line numbers, that /data had no persistent volume.
#
# Read-only by design: it only runs git (show, read-only flags), grep, sed, awk and
# printf. It does not call Docker, does not create temporary files and writes nothing.
# It does NOT repeat the functional persistence test; it only verifies configuration.
# Exit code: 0 = every check gave the expected result, 1 = at least one did not.
# =============================================================================
set -uo pipefail

REPO="${REPO:-/workspaces/dev-portal}"
FILE="docker-compose-dozzle.yml"
TASK=".workspaceScripts/task_dozzle.sh"
BAD=0

say()  { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
note() { printf '    %s\n' "$*"; }
code() { sed 's/^/      | /'; }
result() {  # result <PASS|FAIL> <check> <detail>
  local c='1;32'; [ "$1" = PASS ] || { c='1;31'; BAD=$((BAD + 1)); }
  printf "    \033[${c}m%-5s\033[0m %s (%s)\n" "$1" "$2" "$3"
}
rgit() { git --no-optional-locks -C "$REPO" "$@"; }   # never refreshes the index

say "Step 0: source of the configuration"
YML="$(rgit show "HEAD:$FILE" 2>/dev/null)" || { result FAIL "read $FILE from Git HEAD" "git show failed"; exit 1; }
note "Branch: $(rgit branch --show-current)   HEAD: $(rgit rev-parse --short HEAD)"
note "File: $FILE as committed in HEAD (git show HEAD:$FILE):"
printf '%s\n' "$YML" | cat -n | code

say "Step 1: what the k1-dozzle service mounts"
# Lines of the service-level 'volumes:' list (4-space key, 6-space '- ' items) until the next key.
MOUNTS="$(printf '%s\n' "$YML" | awk '/^    volumes:/{v=1; next} v && /^      - /{print NR": "$0; next} v && /^    [a-z]/{v=0}')"
note "Service volume entries (line: text):"
printf '%s\n' "${MOUNTS:-none}" | code
[ -n "$MOUNTS" ] && result PASS "the service has a volumes list" "$(printf '%s\n' "$MOUNTS" | wc -l) entry" \
  || result FAIL "the service has a volumes list" "none found"
DATA="$(printf '%s\n' "$MOUNTS" | grep -E ':/data"?$')"
[ -z "$DATA" ] && result PASS "no entry mounts /data (defect present in HEAD)" "only the Docker socket is mounted" \
  || result FAIL "no entry mounts /data (defect present in HEAD)" "found: $DATA"

say "Step 2: top-level volume declarations"
TOP="$(printf '%s\n' "$YML" | grep -n -E '^volumes:')"
[ -z "$TOP" ] && result PASS "no top-level 'volumes:' block in HEAD" "no named volume is declared" \
  || result FAIL "no top-level 'volumes:' block in HEAD" "found at line ${TOP%%:*}"

say "Step 3: why that loses data"
DOWN="$(grep -n 'down' "$REPO/$TASK" | head -1)"
note "$TASK:${DOWN%%:*}  ${DOWN#*:}"
note "On Ctrl+C the task removes the container. With no volume on /data, everything Dozzle"
note "stored there (setup wizard choices, users.yml, notification rules) is removed with it."
[ -n "$DOWN" ] && result PASS "the task removes the container on exit" "line ${DOWN%%:*}" \
  || result FAIL "the task removes the container on exit" "down line not found"

say "Historical functional test (NOT re-run by this script)"
note "Before the incident, the earlier BEFORE demo started this HEAD configuration in a temporary"
note "project, stored a test webhook destination and repeated the task's down/up cycle. Recorded:"
note "  /data mounted: FAIL | dataPersisted: false | test setting survives down/up: FAIL (lost)"
note "That demo was retired after the incident. This script only verifies the configuration."

say "Result"
if [ "$BAD" -eq 0 ]; then
  printf '\n\033[1;31mBEFORE RESULT: confirmed in the committed file - /data has no persistent volume, so Dozzle\n'
  printf 'settings are lost when the task removes the container.\033[0m\n'; exit 0
fi
printf '\n\033[1;33mBEFORE RESULT: %d check(s) did not give the expected result (see above).\033[0m\n' "$BAD"; exit 1
