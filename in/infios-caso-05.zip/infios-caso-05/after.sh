#!/usr/bin/env bash
# =============================================================================
# Infios Dev Portal - Case 05 (Kiro SDLC configuration) - AFTER
#
# 1. Runs the CORRECTED UIKit steering copy loop (taken from the working tree's
#    .workspaceScripts/task_setupSdlc.sh) on the real package files, in a temporary
#    folder, and resolves every path from the workspace root (same check as before.sh).
# 2. Checks that the result is exactly the current .kiro/steering/uikit-usage.md,
#    that uikit-foundations.md is untouched, and that running the loop twice does
#    not add the folder twice.
# 3. Audits the other onboarding files (hook, settings, MCP) with read-only checks.
# 4. Optional (SKIP_AGENT=1 skips it): the SDLC agent reads the Button API file at
#    the path the steering gives; the proof is Kiro's own session record.
#
# Writes only to temporary folders; the repository and personal config are not changed.
# =============================================================================
set -uo pipefail

REPO="${REPO:-/workspaces/dev-portal}"
SRC="$REPO/sharedUIComponents/node_modules/@infios/uikit/dist/steering"
WORK="$(mktemp -d /tmp/infios-caso05-after.XXXXXX)"
trap 'rm -rf "$WORK"' EXIT
FAILED=0

say()  { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
note() { printf '    %s\n' "$*"; }
code() { sed 's/^/      | /'; }
bad()  { printf '    \033[1;31mFAIL: %s\033[0m\n' "$*"; FAILED=1; }
refs() {  # every node_modules/@infios/... path in a file, with its line number
  grep -n -o -E '(^|[^/A-Za-z0-9_.-])(([A-Za-z0-9_-]+/)?node_modules/@infios/uikit(\.test)?/dist/[A-Za-z0-9_./-]*)' "$1" \
    | sed -E 's#^([0-9]+):[^A-Za-z0-9_]*#\1 #; s#[.]$##' | sort -t' ' -k2 -u
}

# --- Step 1: the corrected copy loop ---------------------------------------------
say "Step 1: CORRECTED UIKit steering copy loop (working tree .workspaceScripts/task_setupSdlc.sh)"
awk '/for file in "\$UIKIT_STEERING"\/\*\.md; do/{p=1} p{print} p&&/^    done$/{exit}' \
  "$REPO/.workspaceScripts/task_setupSdlc.sh" > "$WORK/copy-loop.sh"
[ -s "$WORK/copy-loop.sh" ] || { bad "corrected loop not found in task_setupSdlc.sh"; exit 1; }
START=$(grep -n -F 'for file in "$UIKIT_STEERING"/*.md; do' "$REPO/.workspaceScripts/task_setupSdlc.sh" | cut -d: -f1)
awk -v s="$START" '{printf "      task_setupSdlc.sh:%d  %s\n", s+NR-1, $0}' "$WORK/copy-loop.sh"
mkdir -p "$WORK/.kiro/steering"
UIKIT_STEERING="$SRC" KIRO_DIR="$WORK/.kiro" bash -c "source '$WORK/copy-loop.sh'"
note "Generated: $(ls "$WORK/.kiro/steering" | tr '\n' ' ')"

# --- Step 2: same path check as before.sh ----------------------------------------
say "Step 2: paths the steering tells Kiro to read, resolved from the workspace root ($REPO)"
MISSING=0; TOTAL=0
for f in "$WORK"/.kiro/steering/*.md; do
  while read -r line path; do
    [ -n "$path" ] || continue
    TOTAL=$((TOTAL + 1))
    if [ -e "$REPO/$path" ]; then note "$(basename "$f"):$line  $path  ->  found"
    elif [[ "$path" == e2e/node_modules/@infios/uikit.test/* ]] && grep -q '"@infios/uikit.test"' "$REPO/e2e/package.json"; then
      note "$(basename "$f"):$line  $path  ->  correct folder (e2e/package.json declares @infios/uikit.test; not installed in this Dev Container)"
    else note "$(basename "$f"):$line  $path  ->  NOT FOUND"; MISSING=$((MISSING + 1)); fi
  done < <(refs "$f")
done
[ "$TOTAL" -gt 0 ] || bad "no paths found to check"
[ "$MISSING" = 0 ] || bad "$MISSING path(s) still do not resolve"

# --- Step 3: consistency ------------------------------------------------------------
say "Step 3: consistency with the workspace and idempotency"
cmp -s "$WORK/.kiro/steering/uikit-usage.md" "$REPO/.kiro/steering/uikit-usage.md" \
  && note "uikit-usage.md generated here == .kiro/steering/uikit-usage.md in the workspace" || bad "workspace uikit-usage.md differs from the loop output"
cmp -s "$WORK/.kiro/steering/uikit-foundations.md" "$SRC/uikit-foundations.md" \
  && note "uikit-foundations.md is still a verbatim copy of the package (it has no node_modules paths)" || bad "uikit-foundations.md changed"
mkdir -p "$WORK/twice/.kiro/steering"
UIKIT_STEERING="$WORK/.kiro/steering" KIRO_DIR="$WORK/twice/.kiro" bash -c "source '$WORK/copy-loop.sh'"
cmp -s "$WORK/twice/.kiro/steering/uikit-usage.md" "$WORK/.kiro/steering/uikit-usage.md" \
  && note "Running the loop on its own output changes nothing (no sharedUIComponents/sharedUIComponents/...)" || bad "loop is not idempotent"
note "Lines changed against the package file: $(diff "$SRC/uikit-usage.md" "$WORK/.kiro/steering/uikit-usage.md" | grep -c '^>')"

# --- Step 4: audit of the other onboarding files (read only) ------------------------
say "Step 4: audit of the other onboarding files"
H="$REPO/.kiro/hooks/infios-output-guard.json"
CMD="$(node -p "require('$H').hooks[0].action.command")"
note "Hook (.kiro/hooks/infios-output-guard.json): trigger=$(node -p "require('$H').hooks[0].trigger") matcher=$(node -p "require('$H').hooks[0].matcher")"
ev() { node -e 'console.log(JSON.stringify({hook_event_name:"PreToolUse",cwd:process.argv[1],tool_name:"execute_bash",tool_input:{command:process.argv[2]}}))' "$REPO" "$1"; }
for c in "git status" "node .kiro/helpers/output-guard.cjs run -- 'git status'"; do
  (cd "$REPO" && ev "$c" | sh -c "$CMD" >/dev/null 2>&1); rc=$?
  note "  hook on: $c  -> exit $rc ($( [ $rc = 2 ] && echo blocked || echo allowed))"
done
note "  (the hook only reads the event and the command text; it runs nothing else)"
note "Workspace settings (.kiro/settings/cli.json):"
(cd "$REPO" && kiro-cli settings list --all 2>/dev/null) | grep -A2 -E '^(chat\.defaultAgent|chat\.enableContextUsageIndicator|chat\.modelDefaults)$' | grep -E '^chat|Current' | paste - - | sed -E 's/ +Current: / = /' | code
note "MCP servers seen by the sdlc agent (workspace github/snyk + personal ado from Case 04):"
(cd "$REPO" && kiro-cli mcp list 2>&1) | sed 's/\x1b\[[0-9;]*m//g' | awk '/^  sdlc *$/{p=1;next} p&&/^  [a-z]/{exit} p' | code

# --- Step 5: the SDLC agent follows the corrected steering --------------------------
say "Step 5: SDLC agent reads the Button API reference at the path the steering gives"
if [ "${SKIP_AGENT:-0}" = 1 ]; then note "SKIP_AGENT=1: skipped"; else
  PROMPT='Using only your steering rules, find the folder where the @infios/uikit component API reference files are, and read uikit-button.md from that folder with your file read tool, exactly once, using the path exactly as the steering writes it. Do not search or list directories. Then answer in two lines: "PATH: <path you read>" and "TITLE: <first markdown heading of the file>".'
  touch "$WORK/marker"; sleep 1
  (cd "$REPO" && timeout 600 kiro-cli chat --agent sdlc --no-interactive --trust-tools=fs_read,read "$PROMPT") > "$WORK/agent.txt" 2>&1
  note "Model answer (text only, not proof):"; sed 's/\x1b\[[0-9;]*m//g' "$WORK/agent.txt" | grep -E '^(PATH|TITLE):' | sed -E 's/\[INFO\].*//' | code
  SESSION="$(find "$HOME/.kiro/sessions" -name messages.jsonl -newer "$WORK/marker" 2>/dev/null | xargs -r grep -l -F 'Using only your steering rules' | head -1)"
  if [ -z "$SESSION" ]; then bad "no Kiro session record for this run"; else
    node - "$SESSION" "$REPO" > "$WORK/verify.txt" <<'JS'
const fs = require('fs'), path = require('path');
const [file, repo] = process.argv.slice(2);
const ev = fs.readFileSync(file, 'utf8').trim().split('\n').map(l => { try { return JSON.parse(l).payload; } catch { return {}; } });
const calls = ev.filter(p => p.type === 'tool_call' && JSON.stringify(p.args || {}).includes('uikit-button.md'));
const call = calls[0];
const res = call && ev.find(p => p.type === 'tool_result' && p.toolCallId === call.toolCallId);
const args = JSON.stringify(call?.args || {});
const p = (args.match(/"(?:path|file_path|paths?)":\s*\[?"([^"]+uikit-button\.md)"/) || [])[1] || '';
const rel = p.startsWith(repo + '/') ? p.slice(repo.length + 1) : p;
const content = typeof res?.content === 'string' ? res.content : JSON.stringify(res?.content || '');
const checks = [
  ['tool call that reads uikit-button.md', !!call, call ? `${call.toolName} ${rel}` : 'none'],
  ['path is the one the corrected steering gives', rel === 'sharedUIComponents/node_modules/@infios/uikit/dist/steering/components/uikit-button.md', rel || '-'],
  ['the call completed and returned the file', res?.success === true && /infios-button/.test(content), res ? `success=${res.success}, ${content.length} chars` : 'no result'],
  ['no directory search was needed', calls.length === 1 && !ev.some(e => e.type === 'tool_call' && /glob|grep|list|search|file_search/i.test(e.toolName || '')), `${calls.length} read(s)`],
];
for (const [n, ok, d] of checks) console.log(`${ok ? 'OK  ' : 'FAIL'} ${n} (${d})`);
process.exit(checks.every(c => c[1]) ? 0 : 1);
JS
    rc=$?; code < "$WORK/verify.txt"; [ "$rc" = 0 ] || bad "the session record does not prove the agent read the file at the steering path"
  fi
fi

if [ "$FAILED" = 0 ]; then
  printf '\n\033[1;32mAFTER RESULT: every path the UIKit steering gives resolves from the workspace root, the\n'
  printf 'workspace steering matches the corrected setup step, and the other onboarding files check out.\033[0m\n'; exit 0
fi
printf '\n\033[1;31mAFTER RESULT: at least one check failed (see FAIL lines).\033[0m\n'; exit 1
