#!/usr/bin/env bash
# =============================================================================
# Infios Dev Portal - Case 05 (Kiro SDLC configuration) - BEFORE
#
# Reproduces the defect safely, in a temporary folder:
#   - takes the ORIGINAL UIKit steering copy step from Git HEAD
#     (.workspaceScripts/task_setupSdlc.sh, "cp $UIKIT_STEERING/*.md"),
#   - runs only that step on the real @infios/uikit package files,
#   - resolves every node_modules path the steering tells Kiro to read, from the
#     workspace root (the folder Kiro works in and resolves relative paths from).
# Expected: those paths do not exist from the workspace root, because this repo
# has no root node_modules; @infios/uikit lives in sharedUIComponents/node_modules.
#
# Read only: writes only to a temporary folder; the repository is not changed.
# =============================================================================
set -uo pipefail

REPO="${REPO:-/workspaces/dev-portal}"
SRC="$REPO/sharedUIComponents/node_modules/@infios/uikit/dist/steering"
WORK="$(mktemp -d /tmp/infios-caso05-before.XXXXXX)"
trap 'rm -rf "$WORK"' EXIT

say()  { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
note() { printf '    %s\n' "$*"; }
code() { sed 's/^/      | /'; }

# Every node_modules/@infios/... path written in a steering file, with its line number.
refs() {  # refs <file>
  grep -n -o -E '(^|[^/A-Za-z0-9_.-])(([A-Za-z0-9_-]+/)?node_modules/@infios/uikit(\.test)?/dist/[A-Za-z0-9_./-]*)' "$1" \
    | sed -E 's#^([0-9]+):[^A-Za-z0-9_]*#\1 #; s#[.]$##' | sort -t' ' -k2 -u
}

# --- Step 1: the original copy step ---------------------------------------------
say "Step 1: ORIGINAL UIKit steering copy step (Git HEAD:.workspaceScripts/task_setupSdlc.sh)"
git -C "$REPO" show HEAD:.workspaceScripts/task_setupSdlc.sh > "$WORK/task_setupSdlc.HEAD.sh" || { echo "cannot read HEAD"; exit 2; }
grep -n -E 'UIKIT_STEERING=|cp "\$UIKIT_STEERING"' "$WORK/task_setupSdlc.HEAD.sh" | sed 's#^#      task_setupSdlc.sh (HEAD):#'
[ -d "$SRC" ] || { echo "UIKit package not installed at $SRC"; exit 2; }
note "Package: @infios/uikit $(node -p "require('$REPO/sharedUIComponents/node_modules/@infios/uikit/package.json').version")"
mkdir -p "$WORK/.kiro/steering"
# Exactly the original step, run on the real package files into a temporary .kiro folder.
UIKIT_STEERING="$SRC"; KIRO_DIR="$WORK/.kiro"
eval "$(grep -E '^\s*cp "\$UIKIT_STEERING"/\*\.md "\$KIRO_DIR/steering/"' "$WORK/task_setupSdlc.HEAD.sh")"
note "Copied: $(ls "$WORK/.kiro/steering" | tr '\n' ' ')"
cmp -s "$WORK/.kiro/steering/uikit-usage.md" "$REPO/sharedUIComponents/node_modules/@infios/uikit/dist/steering/uikit-usage.md" \
  && note "uikit-usage.md is a verbatim copy of the package file (as the original step produced it)."

# --- Step 2: resolve the paths from the workspace root ---------------------------
say "Step 2: paths the steering tells Kiro to read, resolved from the workspace root ($REPO)"
MISSING=0; TOTAL=0
for f in "$WORK"/.kiro/steering/*.md; do
  while read -r line path; do
    [ -n "$path" ] || continue
    TOTAL=$((TOTAL + 1))
    if [ -e "$REPO/$path" ]; then r="found"; else r="NOT FOUND"; MISSING=$((MISSING + 1)); fi
    where=""; for d in sharedUIComponents adminUi tenantUi e2e; do [ -e "$REPO/$d/$path" ] && where="$where $d/"; done
    note "$(basename "$f"):$line  $path  ->  $r${where:+  (exists under:$where)}"
  done < <(refs "$f")
done
note "Root node_modules folder: $([ -e "$REPO/node_modules" ] && echo present || echo 'does not exist')"
note "Kiro session working directory (session.json workspacePaths): $(node -e 'const fs=require("fs"),p=require("path"),d=process.env.HOME+"/.kiro/sessions";const ws=new Set();for(const w of fs.readdirSync(d))for(const s of (fs.statSync(p.join(d,w)).isDirectory()?fs.readdirSync(p.join(d,w)):[])){try{for(const x of JSON.parse(fs.readFileSync(p.join(d,w,s,"session.json"),"utf8")).workspacePaths||[])ws.add(x)}catch{}}console.log([...ws].join(", ")||"unknown")' 2>/dev/null)"

# --- Step 3: what the steering instructs -----------------------------------------
say "Step 3: the instruction that depends on those paths (uikit-usage.md)"
grep -n -E 'Before using a component, read its reference file|read the foundations reference file' "$WORK/.kiro/steering/uikit-usage.md" | cut -c1-170 | code

if [ "$MISSING" -gt 0 ]; then
  printf '\n\033[1;31mBEFORE RESULT: %s of %s paths that the steering tells Kiro to read do not exist from the\n' "$MISSING" "$TOTAL"
  printf 'workspace root; the files are under sharedUIComponents/ (uikit) or e2e/ (uikit.test).\033[0m\n'
  exit 0
fi
printf '\n\033[1;33mBEFORE RESULT: the defect could not be reproduced: every path resolved.\033[0m\n'
exit 1
