#!/usr/bin/env bash
# =============================================================================
# Infios Dev Portal - Case 03 (wrong browser port) - demonstration script
#
# PHASE=before: runs the ORIGINAL .workspaceScripts/open-when-ready.sh (from Git HEAD).
# PHASE=after : runs the CORRECTED open-when-ready.sh from the working tree.
# Everything else is identical, so the helper version is the only variable.
#
# What it does, using the real Dev Portal files and applications:
#   1. Prints the real call chain: .vscode/tasks.json -> task_devStart.sh ->
#      task_startDevPortalDevUI.sh -> open-when-ready.sh -> "$BROWSER" (VS Code).
#   2. Shows where the UI ports really listen (Docker host) and that nothing listens
#      on those ports inside this Dev Container.
#   3. Uses the running real UI containers if "Dev: Start UI" is already up (read only).
#      Otherwise starts TEMPORARY copies of the real Admin and Tenant UIs (real images,
#      real code, real dependencies from a copy of the pnpm store) on ports 45001/45002.
#   4. Runs open-when-ready.sh with the same arguments as task_startDevPortalDevUI.sh,
#      through a wrapper that records the exact URL handed to VS Code before calling
#      the real "$BROWSER". A browser tab opens on your computer.
#   5. Applies VS Code's own rule (src/vs/platform/tunnel/common/tunnel.ts) to that URL
#      and watches VS Code's remote log for tunnels that fail inside the Dev Container.
#
# Safety: creates only resources named infios-caso03-<phase>*, never mounts the real
# workspace volume, never writes to the repository, .env or node_modules, never copies
# ~/.npmrc, and removes only its own resources on exit (KEEP=1 keeps them).
# NO_BROWSER=1 records the URL without opening a tab.
# Run it from a terminal inside the Infios Dev Portal Dev Container. Do not run
# before.sh and after.sh at the same time.
# =============================================================================
set -uo pipefail

PHASE="before"
REPO="${REPO:-/workspaces/dev-portal}"
STORE_SRC="${STORE_SRC:-/workspaces/.pnpm-store}"
PROJECT="infios-caso03-${PHASE}"
VOLUME="${PROJECT}-vol"
TEMP_ADMIN_PORT="${TEMP_ADMIN_PORT:-$([ "$PHASE" = before ] && echo 45001 || echo 45011)}"
TEMP_TENANT_PORT="${TEMP_TENANT_PORT:-$([ "$PHASE" = before ] && echo 45002 || echo 45012)}"
# Each phase uses its own ports: a tunnel that VS Code opened in before.sh keeps
# listening on your computer and would capture the same port in after.sh.
WATCH_SECONDS="${WATCH_SECONDS:-20}"
APPS=(sharedUIComponents adminUi tenantUi)
WORK="$(mktemp -d "/tmp/${PROJECT}.XXXXXX")"
HELPER_REL=".workspaceScripts/open-when-ready.sh"
REAL_BROWSER="${BROWSER:-}"

say()  { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
note() { printf '    %s\n' "$*"; }
code() { sed 's/^/      | /'; }
fail() { printf '\n\033[1;31mERROR: %s\033[0m\n' "$*" >&2; exit 2; }

# Prints "file:line: text" for the first line matching a fixed string.
show_line() {  # show_line <file> <fixed string>
  local hit; hit="$(grep -n -F -- "$2" "$1" | head -1)"
  [ -n "$hit" ] && printf '      %s:%s\n' "${1#"$REPO"/}" "$hit" || printf '      %s: (not found: %s)\n' "${1#"$REPO"/}" "$2"
}

# VS Code rule, copied from extractLocalHostUriMetaDataForPortMapping() in
# src/vs/platform/tunnel/common/tunnel.ts (VS Code commit of this Dev Container):
#   /^(localhost|127\.0\.0\.1|0\.0\.0\.0):(\d+)$/.exec(uri.authority)
vscode_tunnels() {  # vscode_tunnels <url>; prints the remote port that VS Code would tunnel, or nothing
  local authority; authority="$(printf '%s' "$1" | sed -E 's#^https?://([^/?#]*).*#\1#')"
  printf '%s' "$authority" | grep -qE '^(localhost|127\.0\.0\.1|0\.0\.0\.0):[0-9]+$' && printf '%s' "${authority##*:}"
}

remote_log() { ls -t "$HOME"/.vscode-server/data/logs/*/remoteagent.log 2>/dev/null | head -1; }

snapshot() {  # read-only fingerprint of the real environment
  {
    docker ps -a --format '{{.ID}} {{.Names}} {{.State}}' | grep -v infios-caso03 | sort
    docker ps -q | xargs -r docker inspect -f '{{.Name}} {{.State.StartedAt}} {{.Config.User}}' | grep -v infios-caso03 | sort
    docker volume ls -q | grep -v infios-caso03 | sort
    git -C "$REPO" branch --show-current
    git -C "$REPO" status --porcelain
    git -C "$REPO" diff | sha256sum
    sha256sum "$REPO/.env" "$HOME/.npmrc" 2>/dev/null
    for d in "${APPS[@]}"; do stat -c '%Y %u:%g %n' "$REPO/$d/node_modules" 2>/dev/null; done
  } > "$1" 2>&1
}

compose() {  # temporary copies only: real compose file + override, temporary env file
  docker compose -p "$PROJECT" --project-directory "$REPO" --env-file "$WORK/demo.env" \
    -f "$REPO/docker-compose-devui.yml" -f "$WORK/override.yml" "$@"
}

cleanup() {
  local rc=$?
  if [ "${KEEP:-0}" = "1" ]; then say "KEEP=1: keeping $PROJECT resources and $WORK"; exit $rc; fi
  if [ "${TEMP_APPS:-0}" = "1" ]; then
    compose down --remove-orphans >/dev/null 2>&1
    docker volume rm "$VOLUME" >/dev/null 2>&1
    docker image rm "${PROJECT}-dev-portal-admin-ui" "${PROJECT}-dev-portal-tenant-ui" >/dev/null 2>&1
  fi
  rm -rf "$WORK"
  exit $rc
}

# --- Step 0: preconditions ---------------------------------------------------
say "Step 0 ($PHASE): preconditions"
command -v docker >/dev/null || fail "docker is not available"
git -C "$REPO" rev-parse --git-dir >/dev/null 2>&1 || fail "$REPO is not a Git repository"
[ -n "$REAL_BROWSER" ] || note "BROWSER is not set (not a VS Code terminal?): the URL is recorded but no tab opens."
[ -z "$(docker ps -aq --filter "name=^${PROJECT}")" ] || fail "containers named ${PROJECT}* already exist; remove them first"
docker volume inspect "$VOLUME" >/dev/null 2>&1 && fail "volume $VOLUME already exists; remove it first"
trap cleanup EXIT
snapshot "$WORK/env-start.txt"
note "BROWSER=${REAL_BROWSER:-<unset>}"
note "Real environment fingerprint saved."

# --- Step 1: the helper version and the real call chain ---------------------
say "Step 1: which open-when-ready.sh is used, and how the task reaches it"
if [ "$PHASE" = "before" ]; then
  git -C "$REPO" show "HEAD:$HELPER_REL" > "$WORK/open-when-ready.sh" || fail "cannot read $HELPER_REL from HEAD"
  note "ORIGINAL helper from Git HEAD (blob $(git -C "$REPO" rev-parse "HEAD:$HELPER_REL"))"
else
  cp "$REPO/$HELPER_REL" "$WORK/open-when-ready.sh"
  note "CORRECTED helper from the working tree. Change against HEAD:"
  git -C "$REPO" diff HEAD -- "$HELPER_REL" | grep -E '^[-+][^-+]' | code
fi
HELPER="$WORK/open-when-ready.sh"
note "Call chain when you pick Terminal > Run Task > Dev: Start UI > Development:"
show_line "$REPO/.vscode/tasks.json" '"label": "Dev: Start UI"'
show_line "$REPO/.vscode/tasks.json" 'task_devStart.sh ui ${input:mode}'
show_line "$REPO/.workspaceScripts/task_devStart.sh" 'ui:Development)'
show_line "$REPO/.workspaceScripts/task_startDevPortalDevUI.sh" 'open-when-ready.sh http://localhost:35001/'
show_line "$REPO/.workspaceScripts/task_startDevPortalDevUI.sh" 'open-when-ready.sh http://localhost:35002/'
note "Lines of this helper that build and open the URL:"
grep -n -E 'BROWSER_URL=|OPEN_URL=|"\$BROWSER" ' "$HELPER" | sed "s#^#      $HELPER_REL:#"

# --- Step 2: where the ports really listen ----------------------------------
say "Step 2: where ports 35001/35002 listen"
show_line "$REPO/docker-compose-devui.yml" '"35001:80"'
show_line "$REPO/docker-compose-devui.yml" '"35002:80"'
show_line "$REPO/.devcontainer/devcontainer.json" 'docker-outside-of-docker'
note "Docker daemon: $(docker info -f '{{.OperatingSystem}}' 2>/dev/null). Published ports open on the Docker host,"
note "which is the machine where your browser runs; this Dev Container only talks to that daemon."
for p in 35001 35002 "$TEMP_ADMIN_PORT"; do
  if timeout 3 bash -c "exec 3<>/dev/tcp/127.0.0.1/$p" 2>/dev/null; then r="OPEN"; else r="refused (nothing listens)"; fi
  note "Inside this Dev Container, 127.0.0.1:$p -> $r"
done

# --- Step 3: real UI applications --------------------------------------------
say "Step 3: real Admin and Tenant UI"
if [ "$(docker inspect -f '{{.State.Running}}' dev-portal-admin-ui 2>/dev/null)" = "true" ] && \
   [ "$(docker inspect -f '{{.State.Running}}' dev-portal-tenant-ui 2>/dev/null)" = "true" ] && [ "${FORCE_TEMP:-0}" != "1" ]; then
  TEMP_APPS=0
  ADMIN_C=dev-portal-admin-ui; TENANT_C=dev-portal-tenant-ui; ADMIN_P=35001; TENANT_P=35002
  note "Using the running containers from Dev: Start UI (read only): $ADMIN_C, $TENANT_C."
else
  TEMP_APPS=1
  ADMIN_C="${PROJECT}-admin-ui"; TENANT_C="${PROJECT}-tenant-ui"; ADMIN_P="$TEMP_ADMIN_PORT"; TENANT_P="$TEMP_TENANT_PORT"
  note "Dev: Start UI is not running: starting temporary copies of the real UIs on $ADMIN_P/$TENANT_P."
  [ -d "$STORE_SRC/v10" ] || fail "real pnpm store not found at $STORE_SRC/v10 (run Dev: Start UI once first)"
  for p in "$ADMIN_P" "$TENANT_P"; do
    docker ps --format '{{.Ports}}' | grep -q ":$p->" && fail "port $p is already published by another container; set TEMP_ADMIN_PORT/TEMP_TENANT_PORT"
  done
  printf 'DEVCONTAINER_VOLUME=%s\nDEV_UID=%s\nDEV_GID=%s\n' "$VOLUME" "$(id -u)" "$(id -g)" > "$WORK/demo.env"
  printf 'services:\n  dev-portal-admin-ui:\n    container_name: %s\n    ports: !override ["%s:80"]\n  dev-portal-tenant-ui:\n    container_name: %s\n    ports: !override ["%s:80"]\n' \
    "$ADMIN_C" "$ADMIN_P" "$TENANT_C" "$TENANT_P" > "$WORK/override.yml"
  compose build >"$WORK/build.log" 2>&1 || { tail -20 "$WORK/build.log"; fail "image build failed"; }
  IMG="${PROJECT}-dev-portal-admin-ui"
  docker volume create "$VOLUME" >/dev/null || fail "cannot create $VOLUME"
  docker run --rm --user 0 -v "$VOLUME:/v" --entrypoint sh "$IMG" -c "mkdir -p /v/dev-portal && chown $(id -u):$(id -g) /v /v/dev-portal" || fail "cannot prepare $VOLUME"
  git -C "$REPO" ls-files -z "${APPS[@]}" | tar -C "$REPO" --null -T - -cf - \
    | docker run --rm -i --user "$(id -u):$(id -g)" -v "$VOLUME:/v" -w /v/dev-portal --entrypoint tar "$IMG" -xf - || fail "cannot copy code"
  tar -C "$(dirname "$STORE_SRC")" -cf - "$(basename "$STORE_SRC")" \
    | docker run --rm -i --user "$(id -u):$(id -g)" -v "$VOLUME:/v" -w /v --entrypoint tar "$IMG" -xf - || fail "cannot copy the pnpm store"
  note "Copied $(git -C "$REPO" ls-files "${APPS[@]}" | wc -l) tracked files and the real pnpm store to $VOLUME."
  docker run --rm --user "$(id -u):$(id -g)" -e HOME=/tmp/home -v "$VOLUME:/app" -w /app/dev-portal --entrypoint sh "$IMG" -c \
    'for d in sharedUIComponents adminUi tenantUi; do pnpm -C $d install --frozen-lockfile --offline >/dev/null 2>&1 || exit 1; done' \
    || fail "offline install of the real dependencies failed"
  note "Real dependencies installed offline from the store copy."
  compose up -d >/dev/null 2>&1 || fail "cannot start the temporary UIs"
  note "Started $ADMIN_C (host port $ADMIN_P) and $TENANT_C (host port $TENANT_P) with CMD pnpm dev --host."
fi

# --- Step 4: run the helper exactly as the task does -------------------------
say "Step 4: run open-when-ready.sh with the arguments of task_startDevPortalDevUI.sh"
cat > "$WORK/browser-wrapper.sh" <<WRAP
#!/usr/bin/env sh
# Records the URL that open-when-ready.sh hands to VS Code, then calls the real helper.
printf '%s\n' "\$*" >> "$WORK/browser-calls.log"
[ "\${NO_BROWSER:-0}" = "1" ] || [ -z "$REAL_BROWSER" ] || exec "$REAL_BROWSER" "\$@"
WRAP
chmod +x "$WORK/browser-wrapper.sh"; : > "$WORK/browser-calls.log"
LOG="$(remote_log)"; LOG_START=$( [ -n "$LOG" ] && wc -l < "$LOG" || echo 0 )
note "Command 1: bash open-when-ready.sh http://localhost:$ADMIN_P/ 120 $ADMIN_C wget -q -O /dev/null http://127.0.0.1/devportal/adminui/"
BROWSER="$WORK/browser-wrapper.sh" bash "$HELPER" "http://localhost:$ADMIN_P/" 120 \
  "$ADMIN_C" wget -q -O /dev/null http://127.0.0.1/devportal/adminui/ | code
note "Command 2: bash open-when-ready.sh http://localhost:$TENANT_P/ 120 $TENANT_C wget -q -O /dev/null http://127.0.0.1/devportal/tenantui/"
BROWSER="$WORK/browser-wrapper.sh" bash "$HELPER" "http://localhost:$TENANT_P/" 120 \
  "$TENANT_C" wget -q -O /dev/null http://127.0.0.1/devportal/tenantui/ | code
note "URLs handed to \$BROWSER (VS Code openExternal):"
code < "$WORK/browser-calls.log"

# --- Step 5: what VS Code does with each URL ---------------------------------
say "Step 5: VS Code rule for these URLs (allowTunneling: true for \$BROWSER / --openExternal)"
TUNNELED=0
while read -r url; do
  port="$(vscode_tunnels "$url")"
  if [ -n "$port" ]; then
    TUNNELED=$((TUNNELED + 1))
    note "$url -> TUNNELED: VS Code forwards it to 127.0.0.1:$port INSIDE this Dev Container, and opens"
    note "   http://localhost:<local port> in your browser (another port, e.g. 55400, if $port is in use on your computer)."
  else
    note "$url -> NOT tunneled: VS Code opens it unchanged; *.localhost is your computer's loopback, where Docker published the port."
  fi
done < "$WORK/browser-calls.log"
if [ -n "$LOG" ] && [ -n "$REAL_BROWSER" ] && [ "${NO_BROWSER:-0}" != "1" ]; then
  note "Watching $LOG for ${WATCH_SECONDS}s (the browser connects through any tunnel in that time)..."
  sleep "$WATCH_SECONDS"
  tail -n +"$((LOG_START + 1))" "$LOG" | grep -E "Failed to connect tunnel to localhost:($ADMIN_P|$TENANT_P)" > "$WORK/tunnel-errors.txt"
  FAILURES=$(wc -l < "$WORK/tunnel-errors.txt")
  note "New 'Failed to connect tunnel' lines for ports $ADMIN_P/$TENANT_P: $FAILURES"
  sed 's/^/      /' "$WORK/tunnel-errors.txt" | cut -c1-170 | head -6
else
  FAILURES="not observed"; note "Browser not opened, so VS Code's log was not watched."
fi

# --- Step 6: what really answers on the published ports ----------------------
say "Step 6: which service answers"
for pair in "$ADMIN_C:/devportal/adminui/" "$TENANT_C:/devportal/tenantui/"; do
  c="${pair%%:*}"; base="${pair#*:}"
  root="$(docker exec "$c" node -e 'fetch("http://127.0.0.1/",{redirect:"manual"}).then(r=>console.log(r.status,r.headers.get("location")||"")).catch(e=>console.log("error",e.message))' 2>&1)"
  title="$(docker exec "$c" wget -q -O - "http://127.0.0.1$base" 2>/dev/null | grep -o -m1 '<title>[^<]*</title>')"
  note "$c: GET / -> HTTP $root  (the task opens /, Vite redirects to the app base path)"
  note "$c: GET $base -> ${title:-no title}  (Vite of the real app, inside the container)"
  note "$c: published by Docker as $(docker port "$c" 80/tcp 2>/dev/null | tr '\n' ' ')(on the Docker host, not in this Dev Container)"
done

# --- Step 7: result ------------------------------------------------------------
say "Step 7: result"
snapshot "$WORK/env-end.txt"
if diff -q "$WORK/env-start.txt" "$WORK/env-end.txt" >/dev/null; then ENV_OK=1; note "Real environment unchanged."
else ENV_OK=0; note "WARNING: the real environment fingerprint changed:"; diff "$WORK/env-start.txt" "$WORK/env-end.txt" | code; fi
CALLS=$(wc -l < "$WORK/browser-calls.log")
note "Remember to remove any port you see in VS Code's PORTS view for $ADMIN_P/$TENANT_P (right click > Stop Forwarding Port)."
if [ "$PHASE" = "before" ]; then
  if [ "$CALLS" -ge 2 ] && [ "$TUNNELED" = "$CALLS" ] && [ "$ENV_OK" = 1 ]; then
    printf '\n\033[1;31mBEFORE RESULT: the original helper hands localhost URLs to VS Code, which tunnels them to the\n'
    printf 'Dev Container, where nothing listens. Tunnel failures seen in VS Code log: %s.\033[0m\n' "$FAILURES"
    exit 0
  fi
else
  if [ "$CALLS" -ge 2 ] && [ "$TUNNELED" = 0 ] && [ "$ENV_OK" = 1 ] && { [ "$FAILURES" = 0 ] || [ "$FAILURES" = "not observed" ]; }; then
    printf '\n\033[1;32mAFTER RESULT: the corrected helper hands *.localhost URLs to VS Code, which opens them unchanged;\n'
    printf 'no tunnel to the Dev Container (failures: %s). Check that the tabs show the Admin and Tenant UI.\033[0m\n' "$FAILURES"
    exit 0
  fi
fi
printf '\n\033[1;33m%s RESULT: NOT as expected (calls=%s tunneled=%s failures=%s env=%s).\033[0m\n' \
  "${PHASE^^}" "$CALLS" "$TUNNELED" "$FAILURES" "$ENV_OK"
exit 1
