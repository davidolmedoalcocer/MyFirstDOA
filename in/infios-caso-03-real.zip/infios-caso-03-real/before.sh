#!/usr/bin/env bash
# =============================================================================
# Infios Dev Portal - Case 03 (wrong browser port) - demonstration script
#
# PHASE=before: ORIGINAL open-when-ready.sh and task_startDevPortalDevUI.sh (Git HEAD).
# PHASE=after : CORRECTED versions from the working tree.
# Everything else is identical, so the script versions are the only variable.
#
# What it does, with the real Dev Portal files and applications:
#   1. Prints the real call chain and the URL that each task script version builds.
#   2. Shows that nothing listens on the UI ports inside this Dev Container.
#   3. Starts TEMPORARY copies of the real Admin and Tenant UIs (real images, real code,
#      real dependencies from a copy of the pnpm store) on fresh ports, so no old VS Code
#      port forward on your computer can interfere. USE_RUNNING=1 uses the containers of
#      "Dev: Start UI" instead (read only, ports 35001/35002).
#   4. Runs the helper with the task's arguments and records the exact URL and the
#      channel (browser.sh or VS Code's CLI socket) that reach VS Code. Tabs open.
#   5. Applies VS Code's own code path to that URL and watches VS Code's remote log for
#      tunnels that fail inside the Dev Container.
#   6. Checks which service answers, and the API's CORS answer for the page origin that
#      the real task would produce.
#
# Safety: creates only resources named infios-caso03-<phase>*, never mounts the real
# workspace volume, never writes to the repository, .env or node_modules, never copies
# ~/.npmrc, and removes only its own resources on exit (KEEP=1 keeps them).
# NO_BROWSER=1 records the URL without opening tabs.
# Run it from a VS Code terminal inside the Dev Container; not at the same time as the
# other phase.
# =============================================================================
set -uo pipefail

PHASE="before"
REPO="${REPO:-/workspaces/dev-portal}"
STORE_SRC="${STORE_SRC:-/workspaces/.pnpm-store}"
PROJECT="infios-caso03-${PHASE}"
VOLUME="${PROJECT}-vol"
# Fresh ports per phase: a tunnel that VS Code opened earlier keeps listening on your
# computer and would capture the same port later.
TEMP_ADMIN_PORT="${TEMP_ADMIN_PORT:-$([ "$PHASE" = before ] && echo 45031 || echo 45041)}"
TEMP_TENANT_PORT="${TEMP_TENANT_PORT:-$([ "$PHASE" = before ] && echo 45032 || echo 45042)}"
WATCH_SECONDS="${WATCH_SECONDS:-20}"
APPS=(sharedUIComponents adminUi tenantUi)
WORK="$(mktemp -d "/tmp/${PROJECT}.XXXXXX")"
HELPER_REL=".workspaceScripts/open-when-ready.sh"
TASK_REL=".workspaceScripts/task_startDevPortalDevUI.sh"
REAL_BROWSER="${BROWSER:-}"
REAL_CURL="$(command -v curl || true)"

say()  { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
note() { printf '    %s\n' "$*"; }
code() { sed 's/^/      | /'; }
fail() { printf '\n\033[1;31mERROR: %s\033[0m\n' "$*" >&2; exit 2; }

# Version of a repository file for this phase: Git HEAD (before) or working tree (after).
phase_file() {  # phase_file <relative path> <destination>
  if [ "$PHASE" = before ]; then git -C "$REPO" show "HEAD:$1" > "$2"; else cp "$REPO/$1" "$2"; fi
}

# URL that a task script version passes to open-when-ready.sh for a port (35001 / 35002).
task_url() {  # task_url <task script copy> <port>
  grep -o -E "open-when-ready\.sh http://localhost:$2/[^ ]*" "$1" | head -1 | sed 's/^open-when-ready\.sh //'
}

# What VS Code does with a URL that reached it through a channel:
#  - browser.sh runs server-cli.js, which sends new URL(url).href (host lowercased);
#  - the CLI socket passes the string unchanged.
# Then extractLocalHostUriMetaDataForPortMapping() (src/vs/platform/tunnel/common/tunnel.ts)
# tunnels it if /^(localhost|127\.0\.0\.1|0\.0\.0\.0):(\d+)$/ matches uri.authority.
vscode_sees() {  # vscode_sees <channel> <url>; prints the string that VS Code evaluates
  if [ "$1" = browser.sh ]; then node -e 'console.log(new URL(process.argv[1]).href)' "$2"; else printf '%s\n' "$2"; fi
}
vscode_tunnels() {  # vscode_tunnels <url as VS Code sees it>; prints the tunneled port or nothing
  local authority; authority="$(printf '%s' "$1" | sed -E 's#^https?://([^/?#]*).*#\1#')"
  printf '%s' "$authority" | grep -qE '^(localhost|127\.0\.0\.1|0\.0\.0\.0):[0-9]+$' && printf '%s' "${authority##*:}"
}
page_origin() { node -e 'console.log(new URL(process.argv[1]).origin)' "$1"; }  # browser (WHATWG) origin

remote_log() { ls -t "$HOME"/.vscode-server/data/logs/*/remoteagent.log 2>/dev/null | head -1; }

snapshot() {  # read-only fingerprint of the real environment
  {
    docker ps -a --format '{{.ID}} {{.Names}} {{.State}}' | grep -v infios-caso03 | sort
    docker ps -q | xargs -r docker inspect -f '{{.Name}} {{.State.StartedAt}} {{.Config.User}}' | grep -v infios-caso03 | sort
    docker volume ls -q | grep -v infios-caso03 | sort
    git -C "$REPO" branch --show-current
    git -C "$REPO" status --porcelain
    git -C "$REPO" diff | sha256sum
    sha256sum "$REPO/.env" "$HOME/.npmrc" 2>/dev/null
    for d in "${APPS[@]}"; do stat -c '%Y %u:%g %n' "$REPO/$d/node_modules" 2>/dev/null; done
  } > "$1" 2>&1
}

compose() {  # temporary copies only: real compose file + override, temporary env file
  docker compose -p "$PROJECT" --project-directory "$REPO" --env-file "$WORK/demo.env" \
    -f "$REPO/docker-compose-devui.yml" -f "$WORK/override.yml" "$@"
}

cleanup() {
  local rc=$?
  if [ "${KEEP:-0}" = "1" ]; then say "KEEP=1: keeping $PROJECT resources and $WORK"; exit $rc; fi
  if [ "${TEMP_APPS:-0}" = "1" ]; then
    compose down --remove-orphans >/dev/null 2>&1
    docker volume rm "$VOLUME" >/dev/null 2>&1
    docker image rm "${PROJECT}-dev-portal-admin-ui" "${PROJECT}-dev-portal-tenant-ui" >/dev/null 2>&1
  fi
  rm -rf "$WORK"
  exit $rc
}

# --- Step 0: preconditions ---------------------------------------------------
say "Step 0 ($PHASE): preconditions"
command -v docker >/dev/null || fail "docker is not available"
command -v node >/dev/null || fail "node is not available"
git -C "$REPO" rev-parse --git-dir >/dev/null 2>&1 || fail "$REPO is not a Git repository"
[ -n "$REAL_BROWSER" ] || note "BROWSER is not set (not a VS Code terminal?): URLs are recorded but no tab opens."
[ -z "$(docker ps -aq --filter "name=^${PROJECT}")" ] || fail "containers named ${PROJECT}* already exist; remove them first"
docker volume inspect "$VOLUME" >/dev/null 2>&1 && fail "volume $VOLUME already exists; remove it first"
trap cleanup EXIT
snapshot "$WORK/env-start.txt"
note "BROWSER=${REAL_BROWSER:-<unset>}"
note "VSCODE_IPC_HOOK_CLI=${VSCODE_IPC_HOOK_CLI:+<set: VS Code CLI socket>}"
note "Real environment fingerprint saved."

# --- Step 1: the script versions and the real call chain ---------------------
say "Step 1: script versions used, and how the task reaches them"
phase_file "$HELPER_REL" "$WORK/open-when-ready.sh" || fail "cannot read $HELPER_REL"
phase_file "$TASK_REL" "$WORK/task_startDevPortalDevUI.sh" || fail "cannot read $TASK_REL"
HELPER="$WORK/open-when-ready.sh"
if [ "$PHASE" = before ]; then
  note "ORIGINAL scripts from Git HEAD (helper blob $(git -C "$REPO" rev-parse "HEAD:$HELPER_REL"))"
else
  note "CORRECTED scripts from the working tree. Changes against HEAD:"
  git -C "$REPO" diff HEAD -- "$TASK_REL" "$HELPER_REL" | grep -E '^[-+][^-+]' | code
fi
note "Call chain for Terminal > Run Task > Dev: Start UI > Development:"
grep -n -F '"label": "Dev: Start UI"' "$REPO/.vscode/tasks.json" | sed 's#^#      .vscode/tasks.json:#'
grep -n -F 'task_devStart.sh ui ${input:mode}' "$REPO/.vscode/tasks.json" | sed 's#^#      .vscode/tasks.json:#'
grep -n -F 'ui:Development)' "$REPO/.workspaceScripts/task_devStart.sh" | sed 's#^#      .workspaceScripts/task_devStart.sh:#'
grep -n -F 'open-when-ready.sh http://localhost:' "$WORK/task_startDevPortalDevUI.sh" | sed "s#^#      $TASK_REL:#"
note "Lines of this helper that open the browser:"
grep -n -E 'OPEN_URL=|"\$BROWSER" |--unix-socket|"\$VSCODE_IPC_HOOK_CLI"' "$HELPER" | sed "s#^#      $HELPER_REL:#"
ADMIN_TASK_URL="$(task_url "$WORK/task_startDevPortalDevUI.sh" 35001)"
TENANT_TASK_URL="$(task_url "$WORK/task_startDevPortalDevUI.sh" 35002)"
note "URLs this task version passes to the helper: $ADMIN_TASK_URL  $TENANT_TASK_URL"

# --- Step 2: where the ports listen ------------------------------------------
say "Step 2: where the UI ports listen"
grep -n -E '"3500[12]:80"' "$REPO/docker-compose-devui.yml" | sed 's#^#      docker-compose-devui.yml:#'
grep -n -F 'docker-outside-of-docker' "$REPO/.devcontainer/devcontainer.json" | sed 's#^#      .devcontainer/devcontainer.json:#'
note "Docker daemon: $(docker info -f '{{.OperatingSystem}}' 2>/dev/null); published ports open on the Docker host,"
note "the machine where your browser runs. This Dev Container only talks to that daemon."
for p in 35001 35002 "$TEMP_ADMIN_PORT" "$TEMP_TENANT_PORT"; do
  if timeout 3 bash -c "exec 3<>/dev/tcp/127.0.0.1/$p" 2>/dev/null; then r="OPEN"; else r="refused (nothing listens)"; fi
  note "Inside this Dev Container, 127.0.0.1:$p -> $r"
done

# --- Step 3: real UI applications --------------------------------------------
say "Step 3: real Admin and Tenant UI"
if [ "${USE_RUNNING:-0}" = "1" ]; then
  [ "$(docker inspect -f '{{.State.Running}}' dev-portal-admin-ui 2>/dev/null)" = true ] && \
  [ "$(docker inspect -f '{{.State.Running}}' dev-portal-tenant-ui 2>/dev/null)" = true ] || fail "USE_RUNNING=1 but Dev: Start UI is not running"
  TEMP_APPS=0; ADMIN_C=dev-portal-admin-ui; TENANT_C=dev-portal-tenant-ui; ADMIN_P=35001; TENANT_P=35002
  note "USE_RUNNING=1: using the containers of Dev: Start UI (read only). Old VS Code forwards of 35001/35002"
  note "on your computer, if any, can still capture connections (see the guide)."
else
  TEMP_APPS=1
  ADMIN_C="${PROJECT}-admin-ui"; TENANT_C="${PROJECT}-tenant-ui"; ADMIN_P="$TEMP_ADMIN_PORT"; TENANT_P="$TEMP_TENANT_PORT"
  [ -d "$STORE_SRC/v10" ] || fail "real pnpm store not found at $STORE_SRC/v10 (run Dev: Start UI once first)"
  for p in "$ADMIN_P" "$TENANT_P"; do
    docker ps --format '{{.Ports}}' | grep -q ":$p->" && fail "port $p is already published; set TEMP_ADMIN_PORT/TEMP_TENANT_PORT"
  done
  printf 'DEVCONTAINER_VOLUME=%s\nDEV_UID=%s\nDEV_GID=%s\n' "$VOLUME" "$(id -u)" "$(id -g)" > "$WORK/demo.env"
  printf 'services:\n  dev-portal-admin-ui:\n    container_name: %s\n    ports: !override ["%s:80"]\n  dev-portal-tenant-ui:\n    container_name: %s\n    ports: !override ["%s:80"]\n' \
    "$ADMIN_C" "$ADMIN_P" "$TENANT_C" "$TENANT_P" > "$WORK/override.yml"
  compose build >"$WORK/build.log" 2>&1 || { tail -20 "$WORK/build.log"; fail "image build failed"; }
  IMG="${PROJECT}-dev-portal-admin-ui"
  docker volume create "$VOLUME" >/dev/null || fail "cannot create $VOLUME"
  docker run --rm --user 0 -v "$VOLUME:/v" --entrypoint sh "$IMG" -c "mkdir -p /v/dev-portal && chown $(id -u):$(id -g) /v /v/dev-portal" || fail "cannot prepare $VOLUME"
  git -C "$REPO" ls-files -z "${APPS[@]}" | tar -C "$REPO" --null -T - -cf - \
    | docker run --rm -i --user "$(id -u):$(id -g)" -v "$VOLUME:/v" -w /v/dev-portal --entrypoint tar "$IMG" -xf - || fail "cannot copy code"
  tar -C "$(dirname "$STORE_SRC")" -cf - "$(basename "$STORE_SRC")" \
    | docker run --rm -i --user "$(id -u):$(id -g)" -v "$VOLUME:/v" -w /v --entrypoint tar "$IMG" -xf - || fail "cannot copy the pnpm store"
  note "Copied $(git -C "$REPO" ls-files "${APPS[@]}" | wc -l) tracked files and the real pnpm store to $VOLUME."
  docker run --rm --user "$(id -u):$(id -g)" -e HOME=/tmp/home -v "$VOLUME:/app" -w /app/dev-portal --entrypoint sh "$IMG" -c \
    'for d in sharedUIComponents adminUi tenantUi; do pnpm -C $d install --frozen-lockfile --offline >/dev/null 2>&1 || exit 1; done' \
    || fail "offline install of the real dependencies failed"
  compose up -d >/dev/null 2>&1 || fail "cannot start the temporary UIs"
  note "Started $ADMIN_C (host port $ADMIN_P) and $TENANT_C (host port $TENANT_P): real code, CMD pnpm dev --host."
fi
ADMIN_URL="${ADMIN_TASK_URL/:35001\//:$ADMIN_P/}"; TENANT_URL="${TENANT_TASK_URL/:35002\//:$TENANT_P/}"

# --- Step 4: run the helper exactly as the task does -------------------------
say "Step 4: run open-when-ready.sh with the task's arguments"
: > "$WORK/calls.log"
# Recorders: they write the channel and URL that reach VS Code, then call the real program.
cat > "$WORK/browser-wrapper.sh" <<WRAP
#!/usr/bin/env sh
printf 'browser.sh %s\n' "\$*" >> "$WORK/calls.log"
[ "\${NO_BROWSER:-0}" = "1" ] || [ -z "$REAL_BROWSER" ] || exec "$REAL_BROWSER" "\$@"
WRAP
mkdir -p "$WORK/bin"
cat > "$WORK/bin/curl" <<WRAP
#!/usr/bin/env sh
for a in "\$@"; do case "\$a" in *openExternal*) printf 'socket %s\n' "\$(printf '%s' "\$a" | sed -E 's/.*"uris":\["([^"]*)".*/\1/')" >> "$WORK/calls.log" ;; esac; done
[ "\${NO_BROWSER:-0}" = "1" ] && { echo null; exit 0; }
exec "$REAL_CURL" "\$@"
WRAP
chmod +x "$WORK/browser-wrapper.sh" "$WORK/bin/curl"
LOG="$(remote_log)"; LOG_START=$( [ -n "$LOG" ] && wc -l < "$LOG" || echo 0 )
for pair in "$ADMIN_C|$ADMIN_URL|/devportal/adminui/" "$TENANT_C|$TENANT_URL|/devportal/tenantui/"; do
  IFS='|' read -r c url base <<< "$pair"
  note "bash open-when-ready.sh $url 120 $c wget -q -O /dev/null http://127.0.0.1$base"
  PATH="$WORK/bin:$PATH" BROWSER="$WORK/browser-wrapper.sh" bash "$HELPER" "$url" 120 \
    "$c" wget -q -O /dev/null "http://127.0.0.1$base" | code
done
note "What reached VS Code (channel and URL):"
code < "$WORK/calls.log"

# --- Step 5: what VS Code does with each URL ---------------------------------
say "Step 5: VS Code's handling (server-cli.js -> _remoteCLI.openExternal -> resolveExternalUri)"
TUNNELED=0; CALLS=0
while read -r channel url; do
  CALLS=$((CALLS + 1)); seen="$(vscode_sees "$channel" "$url")"; port="$(vscode_tunnels "$seen")"
  note "$channel: $url"
  note "   VS Code evaluates: $seen"
  if [ -n "$port" ]; then
    TUNNELED=$((TUNNELED + 1))
    note "   -> TUNNELED to 127.0.0.1:$port INSIDE this Dev Container; the tab gets the tunnel's local port."
  else
    note "   -> NOT tunneled: opened unchanged; the browser goes to its own localhost, where Docker published the port."
  fi
  note "   Page origin in the browser (WHATWG URL): $(page_origin "$url")"
done < "$WORK/calls.log"
if [ -n "$LOG" ] && [ -n "$REAL_BROWSER" ] && [ "${NO_BROWSER:-0}" != "1" ]; then
  note "Watching $LOG for ${WATCH_SECONDS}s..."
  sleep "$WATCH_SECONDS"
  tail -n +"$((LOG_START + 1))" "$LOG" | grep -E "Failed to connect tunnel to localhost:($ADMIN_P|$TENANT_P)" > "$WORK/tunnel-errors.txt"
  FAILURES=$(wc -l < "$WORK/tunnel-errors.txt")
  note "New 'Failed to connect tunnel' lines for ports $ADMIN_P/$TENANT_P: $FAILURES"
  cut -c1-170 "$WORK/tunnel-errors.txt" | head -6 | sed 's/^/      /'
else
  FAILURES="not observed"; note "Browser not opened, so VS Code's log was not watched."
fi

# --- Step 6: which service answers, and CORS for the real origin -------------
say "Step 6: which service answers"
for pair in "$ADMIN_C|/devportal/adminui/" "$TENANT_C|/devportal/tenantui/"; do
  IFS='|' read -r c base <<< "$pair"
  title="$(docker exec "$c" wget -q -O - "http://127.0.0.1$base" 2>/dev/null | grep -o -m1 '<title>[^<]*</title>')"
  backend="$(docker exec "$c" wget -q -O - "http://127.0.0.1$base" 2>/dev/null | grep -o -m1 'defaultBackendUrl = "[^"]*"')"
  note "$c: GET $base -> ${title:-no title}; $backend"
  note "$c: published by Docker as $(docker port "$c" 80/tcp 2>/dev/null | tr '\n' ' ')"
done
CORS_OK=1
if [ "$(docker inspect -f '{{.State.Running}}' dev-portal-service 2>/dev/null)" = true ]; then
  for pair in "$ADMIN_TASK_URL|/admin/api/users/current" "$TENANT_TASK_URL|/customer/api/users/current"; do
    IFS='|' read -r url api <<< "$pair"
    case "$(head -1 "$WORK/calls.log" | cut -d' ' -f1)" in browser.sh) shown="$(vscode_sees browser.sh "$url")";; *) shown="$url";; esac
    origin="$(page_origin "$shown")"
    acao="$(docker exec dev-portal-service curl -s -o /dev/null -D - -H "Origin: $origin" "http://127.0.0.1:8080$api" | grep -i -m1 '^access-control-allow-origin' | tr -d '\r')"
    note "Real API $api with Origin: $origin (origin of the real task's tab) -> ${acao:-NO Access-Control-Allow-Origin}"
    [ -n "$acao" ] || CORS_OK=0
  done
  note "If the tab gets a tunnel port instead (e.g. http://localhost:55400), its origin is not in the CORS list either."
else
  CORS_OK="not checked"; note "dev-portal-service is not running: start Dev: Start Services to include the CORS check."
fi

# --- Step 7: result ------------------------------------------------------------
say "Step 7: result"
snapshot "$WORK/env-end.txt"
if diff -q "$WORK/env-start.txt" "$WORK/env-end.txt" >/dev/null; then ENV_OK=1; note "Real environment unchanged."
else ENV_OK=0; note "WARNING: the real environment fingerprint changed:"; diff "$WORK/env-start.txt" "$WORK/env-end.txt" | code; fi
[ "$PHASE" = before ] && note "VS Code keeps the forwards this phase created: PORTS view > right click $ADMIN_P/$TENANT_P > Stop Forwarding Port."
if [ "$PHASE" = before ]; then
  if [ "$CALLS" -ge 2 ] && [ "$TUNNELED" = "$CALLS" ] && [ "$ENV_OK" = 1 ]; then
    printf '\n\033[1;31mBEFORE RESULT: the original helper sends localhost URLs through browser.sh; VS Code tunnels them\n'
    printf 'into the Dev Container, where nothing listens. Tunnel failures seen in VS Code log: %s.\033[0m\n' "$FAILURES"
    exit 0
  fi
else
  if [ "$CALLS" -ge 2 ] && [ "$TUNNELED" = 0 ] && [ "$ENV_OK" = 1 ] && [ "$CORS_OK" != 0 ] && \
     { [ "$FAILURES" = 0 ] || [ "$FAILURES" = "not observed" ]; }; then
    printf '\n\033[1;32mAFTER RESULT: the corrected helper sends LOCALHOST through VS Code'"'"'s CLI socket; no tunnel\n'
    printf '(failures: %s), origin stays http://localhost:<port>, API CORS: %s.\033[0m\n' "$FAILURES" "$([ "$CORS_OK" = 1 ] && echo allowed || echo "$CORS_OK")"
    exit 0
  fi
fi
printf '\n\033[1;33m%s RESULT: NOT as expected (calls=%s tunneled=%s failures=%s cors=%s env=%s).\033[0m\n' \
  "${PHASE^^}" "$CALLS" "$TUNNELED" "$FAILURES" "$CORS_OK" "$ENV_OK"
exit 1
