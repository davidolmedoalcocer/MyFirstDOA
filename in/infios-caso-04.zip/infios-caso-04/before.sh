#!/usr/bin/env bash
# =============================================================================
# Infios Dev Portal - Case 04 (Azure DevOps MCP in Kiro CLI) - BEFORE
#
# Shows, with real evidence and without changing anything, why the SDLC agent
# could not use Azure DevOps:
#   1. The real setup warnings of the SDLC framework (infios-sdlc check).
#   2. The workspace MCP files have no "ado" server, and the framework's fix
#      ("infios-sdlc update --ado-org") would pin @azure-devops/mcp@2.10.0.
#   3. LIVE reproduction: the official @azure-devops/mcp@2.10.0, started exactly as
#      the framework would configure it, crashes in this Dev Container
#      (keytar needs libsecret-1.so.0, which the image does not have).
#   4. The race seen in Kiro v3: the first prompt is sent before a slow stdio
#      server finishes connecting, so its tools are not offered (recorded logs).
#   5. Workspace Trust: why the "trust unknown" warning is a false positive.
#
# Read only: no file is written outside a temporary folder, the personal Kiro
# config is only read, and no Azure DevOps call is made. No token is printed.
# Run from a terminal inside the Infios Dev Portal Dev Container.
# =============================================================================
set -uo pipefail

REPO="${REPO:-/workspaces/dev-portal}"
ORG="${ADO_ORG:-highjumpvso}"
FRAMEWORK="$(npm root -g 2>/dev/null)/@infios/agentic-sdlc-flow"
EVIDENCE="${EVIDENCE:-/tmp/infios-caso04-work}"   # recorded logs from the investigation, if present
WORK="$(mktemp -d /tmp/infios-caso04-before.XXXXXX)"
trap 'rm -rf "$WORK"' EXIT

say()  { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
note() { printf '    %s\n' "$*"; }
code() { sed 's/^/      | /'; }

# Starts an MCP server over stdio and runs initialize + tools/list (+ optional call).
# Usage: mcp_probe <call:yes|no> <command> <args...>   (env ado_mcp_project is passed through)
mcp_probe() {
  local call="$1"; shift
  cat > "$WORK/probe.js" <<'JS'
const { spawn } = require('child_process');
const [call, cmd, ...args] = process.argv.slice(2);
const child = spawn(cmd, args, { env: process.env, stdio: ['pipe', 'pipe', 'pipe'] });
let buf = '', err = '', done = false;
const send = (id, method, params) => child.stdin.write(JSON.stringify({ jsonrpc: '2.0', id, method, params }) + '\n');
const end = c => { done = true; clearTimeout(t); child.kill(); process.exit(c); };
const t = setTimeout(() => { console.log('RESULT: timeout'); end(2); }, 150000);
child.stderr.on('data', d => { err += d; });
child.on('exit', c => { if (!done) { console.log(`RESULT: server exited before answering (exit code ${c})`);
  console.log('stderr: ' + (err.match(/Error: .*/) || [err.trim().split('\n').pop()])[0]); process.exit(1); } });
child.stdout.on('data', d => { buf += d; let i;
  while ((i = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, i); buf = buf.slice(i + 1); let m; try { m = JSON.parse(line); } catch { continue; }
    if (m.id === 1) { console.log(`initialize: ${m.result ? m.result.serverInfo.name + ' ' + m.result.serverInfo.version : JSON.stringify(m.error)}`);
      child.stdin.write(JSON.stringify({ jsonrpc: '2.0', method: 'notifications/initialized' }) + '\n'); send(2, 'tools/list', {}); }
    else if (m.id === 2) { const n = (m.result?.tools || []).map(x => x.name); console.log(`tools/list: ${n.length} tools`);
      if (call === 'yes') send(3, 'tools/call', { name: 'core_list_projects', arguments: {} }); else end(0); }
    else if (m.id === 3) { if (m.error || m.result?.isError) { console.log('tools/call core_list_projects: ERROR ' + JSON.stringify(m.error || m.result).slice(0, 300)); end(1); }
      const text = (m.result.content || []).map(c => c.text || '').join(''); let list = [];
      try { list = JSON.parse(text.slice(text.indexOf('\n[') + 1, text.lastIndexOf(']') + 1)); } catch {}
      console.log(`tools/call core_list_projects: ok, ${list.length} projects`); end(0); } } });
send(1, 'initialize', { protocolVersion: '2024-11-05', capabilities: {}, clientInfo: { name: 'infios-caso04-demo', version: '1.0' } });
JS
  node "$WORK/probe.js" "$call" "$@" 2>&1
}

# --- Step 1: the warnings the user saw ---------------------------------------
say "Step 1: real setup warnings of the SDLC framework (infios-sdlc check, read only)"
(cd "$REPO" && infios-sdlc check 2>&1) | sed 's/\x1b\[[0-9;]*m//g' \
  | grep -E 'MCP configuration|Azure DevOps|Workspace trust|Passed|warning' | code
note "Origin of each message in the framework (v$(node -p "require('$FRAMEWORK/package.json').version" 2>/dev/null)):"
grep -n -F "warn('Azure DevOps MCP server not configured')" "$FRAMEWORK/bin/cli.js" | sed "s#^#      bin/cli.js:#" | cut -c1-140
grep -n -F "const mcpPath = path.join(PROJECT_DIR, '.mcp.json');" "$FRAMEWORK/bin/cli.js" | head -1 | sed "s#^#      bin/cli.js:#"
grep -n -F "Workspace trust unknown" "$FRAMEWORK/core/helpers/kiro-engine.cjs" | sed "s#^#      core/helpers/kiro-engine.cjs:#" | cut -c1-140

# --- Step 2: configuration before the fix -------------------------------------
say "Step 2: MCP configuration seen by the SDLC agent before the fix"
for f in "$REPO/.kiro/settings/mcp.json" "$REPO/.mcp.json"; do
  note "${f#"$REPO"/}: servers = $(node -p "Object.keys(require('$f').mcpServers||{}).join(', ')")   (no 'ado')"
done
note "SDLC agent (.kiro/agents/sdlc.json): includeMcpJson=$(node -p "require('$REPO/.kiro/agents/sdlc.json').includeMcpJson"), MCP refs in tools: $(node -p "require('$REPO/.kiro/agents/sdlc.json').tools.filter(t=>t.startsWith('@')).join(', ')")"
if [ -f "$EVIDENCE/before-state/mcp-status-ado.txt" ]; then
  note "Recorded before the fix: kiro-cli mcp status --name ado"
  grep -v '^$' "$EVIDENCE/before-state/mcp-status-ado.txt" | code
  note "Recorded before the fix: ls ~/.kiro/settings/mcp.json"; code < "$EVIDENCE/before-state/user-mcp.ls"
fi
note "Server the framework's own fix would write (core/helpers/ado-auth.js, createAdoServer):"
node -e "const a=require('$FRAMEWORK/core/helpers/ado-auth.js'),v=require('$FRAMEWORK/core/helpers/mcp-services.js').ADO_VERSION;
console.log(JSON.stringify(a.createAdoServer({organization:'$ORG',version:v,env:{}})))" 2>&1 | code

# --- Step 3: live reproduction of the 2.10.0 crash ----------------------------
say "Step 3: LIVE - start the official @azure-devops/mcp@2.10.0 as the framework configures it"
note "(MCP handshake only: initialize + tools/list. No Azure DevOps call.)"
mcp_probe no npx -y @azure-devops/mcp@2.10.0 "$ORG" -d core work work-items -a azcli | code
note "Shared library the 2.10.0 dependency chain needs (@azure/msal-node-extensions -> keytar):"
if ldconfig -p 2>/dev/null | grep -q libsecret-1.so.0; then note "libsecret-1.so.0: present"; else note "libsecret-1.so.0: NOT installed in this image"; fi

# --- Step 4: the startup race (recorded) --------------------------------------
say "Step 4: Kiro v3 sends the first prompt before a slow stdio server connects (recorded logs)"
if ls "$EVIDENCE"/evidence/20261107T221422554-*.txt >/dev/null 2>&1; then
  note "Run without waitForReady (server working, agent answered ADO_TOOLS_UNAVAILABLE):"
  cat "$EVIDENCE/evidence/20261107T221422554-prompt.txt" "$EVIDENCE/evidence/20261107T221422554-mcp-ado.txt" \
    | node -e 'require("readline").createInterface({input:process.stdin}).on("line",l=>{try{const j=JSON.parse(l);console.log(j.timestamp+"  "+(j.message.includes("session/prompt")?"prompt sent to the model":j.message))}catch{}})' \
    | grep -E 'prompt sent|mcp.connect.ok' | code
  note "The prompt left ~6 s before the ado server finished connecting, so its tools were not offered."
else
  note "Recorded logs not found in $EVIDENCE/evidence (they are only on the investigation machine)."
fi

# --- Step 5: Workspace Trust ----------------------------------------------------
say "Step 5: Workspace Trust (a separate mechanism, not related to Azure DevOps)"
for d in "$HOME"/.kiro/workspace-roots/*/; do
  note "$(basename "$d"): files = $(ls -A "$d" | tr '\n' ' ')"
  [ -f "$d/permissions.yaml" ] && code < "$d/permissions.yaml"
done
note "The framework looks only for .trust-migration.json (kiro-engine.cjs, findTrust):"
grep -n -F "'.trust-migration.json'" "$FRAMEWORK/core/helpers/kiro-engine.cjs" | sed "s#^#      core/helpers/kiro-engine.cjs:#"
note "Real untrusted-workspace signals in Kiro logs (executionDisabledUntrustedWorkspace): $(cat "$HOME"/.kiro/logs/*/kiro.log 2>/dev/null | grep -c executionDisabledUntrustedWorkspace)"

printf '\n\033[1;31mBEFORE RESULT: no "ado" server reached the SDLC agent. The framework fix pins 2.10.0, which\n'
printf 'crashes here; even a working server lost the race with the first prompt. The trust warning is a\n'
printf 'false positive of the framework check (the workspace is trusted).\033[0m\n'
