#!/usr/bin/env bash
# =============================================================================
# Infios Dev Portal - Case 04 (Azure DevOps MCP in Kiro CLI) - AFTER
#
# Demonstrates the working integration with real, read-only evidence:
#   1. The personal Kiro MCP config (~/.kiro/settings/mcp.json) with the "ado" server.
#   2. Kiro CLI sees that server for the SDLC agent (kiro-cli mcp list / status).
#   3. Authentication: the Azure CLI login (Microsoft Entra ID) the server uses (-a azcli).
#   4. MCP handshake + one read-only tool call (core_list_projects), outside Kiro.
#   5. The SDLC agent itself calls core_list_projects through Kiro (only that tool is
#      trusted for this one run; nothing is saved).
#   6. Safety: write tools exist but are not auto-approved.
#
# Read only for Azure DevOps and for every config file. No token is printed.
# Run from a terminal inside the Infios Dev Portal Dev Container, after "az login".
# SKIP_AGENT=1 skips step 5 (it uses one model request and takes about a minute).
# =============================================================================
set -uo pipefail

REPO="${REPO:-/workspaces/dev-portal}"
USER_MCP="$HOME/.kiro/settings/mcp.json"
ADO_APP_ID=499b84ac-1321-427f-aa17-267ca6975798   # Azure DevOps resource ID in Entra (public, fixed)
WORK="$(mktemp -d /tmp/infios-caso04-after.XXXXXX)"
trap 'rm -rf "$WORK"' EXIT
FAILED=0

say()  { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
note() { printf '    %s\n' "$*"; }
code() { sed 's/^/      | /'; }
bad()  { printf '    \033[1;31mFAIL: %s\033[0m\n' "$*"; FAILED=1; }

# --- Step 1: the personal configuration ---------------------------------------
say "Step 1: personal Kiro MCP config ($USER_MCP)"
[ -f "$USER_MCP" ] || { bad "$USER_MCP not found"; exit 1; }
note "permissions: $(stat -c '%a %U' "$USER_MCP")  (only your user can read it)"
# Show only the fields that explain the "ado" server. Values that identify the organization,
# the project, or other personal servers are summarized, never printed.
TEAM_ORG="$(grep -A3 -E '^ *ado:' "$REPO/.kiro/team-config.yaml" 2>/dev/null | sed -n -E 's/^ *org: *"?([^"]*)"?.*/\1/p' | head -1)"
node - "$USER_MCP" "$TEAM_ORG" <<'JS' | code
const [file, teamOrg] = process.argv.slice(2);
const all = require(file).mcpServers || {};
const s = all.ado;
if (!s) { console.log('ado server: MISSING'); process.exit(1); }
const a = s.args || [], at = f => { const i = a.indexOf(f); return i < 0 ? [] : a.slice(i + 1); };
const pkg = a.find(x => x.startsWith('@azure-devops/mcp')) || '(none)';
const org = a[a.indexOf(pkg) + 1];
const domains = []; for (const x of at('-d')) { if (x.startsWith('-')) break; domains.push(x); }
console.log(`ado.command        : ${s.command}`);
console.log(`ado.package       : ${pkg}  (official Microsoft package)`);
console.log(`ado.organization  : <hidden>  (same as team-config project_management.ado.org: ${org === teamOrg ? 'yes' : 'no'})`);
console.log(`ado.domains (-d)  : ${domains.join(' ')}`);
console.log(`ado.auth (-a)     : ${at('-a')[0]}  (token from your Azure CLI login, nothing stored here)`);
console.log(`ado.env keys      : ${Object.keys(s.env || {}).join(', ') || '(none)'}  (values hidden)`);
console.log(`ado.timeout       : ${s.timeout} ms`);
console.log(`ado.waitForReady  : ${s.waitForReady === true}`);
console.log(`ado.autoApprove   : ${JSON.stringify(s.autoApprove || [])}  (empty = every ado tool asks before running)`);
const secretish = Object.keys(s.env || {}).filter(k => /token|pat|secret|password/i.test(k));
console.log(`secret-like env   : ${secretish.length ? secretish.join(', ') : 'none'}`);
console.log(`other servers in this file: ${Object.keys(all).length - 1}  (not shown)`);
JS
note "Workspace files are unchanged and still have no 'ado' server:"
for f in .kiro/settings/mcp.json .mcp.json; do note "  $f: $(node -p "Object.keys(require('$REPO/$f').mcpServers).join(', ')")"; done

# --- Step 2: Kiro CLI loads it for the SDLC agent ------------------------------
say "Step 2: Kiro CLI configuration view"
(cd "$REPO" && kiro-cli mcp list 2>&1) | sed 's/\x1b\[[0-9;]*m//g' | awk '/^  sdlc *$/{p=1;print;next} p&&/^  [a-z]/{exit} p' | code
(cd "$REPO" && kiro-cli mcp status --name ado 2>&1) | sed 's/\x1b\[[0-9;]*m//g' | awk '/Agent *: sdlc *$/{p=1} p&&NF{print} p&&/Env Vars/{exit}' \
  | sed -E 's/(Env Vars: [^=]+=).*/\1<hidden>/' | code

# --- Step 3: authentication (Microsoft Entra ID through the Azure CLI) ---------
say "Step 3: Azure CLI login used by the server (-a azcli)"
if az account show >/dev/null 2>&1; then
  note "Signed in: yes (account type: $(az account show --query user.type -o tsv 2>/dev/null); account name not shown)"
  EXP="$(az account get-access-token --resource "$ADO_APP_ID" --query expiresOn -o tsv 2>/dev/null)"
  [ -n "$EXP" ] && note "Entra ID can issue an Azure DevOps token for this login (expires $EXP; token not shown)" \
                || bad "no Azure DevOps token: run az login"
else
  bad "not signed in to the Azure CLI. Run: az login --use-device-code   (then rerun)"; exit 1
fi

# --- Step 4: MCP handshake and one read-only call, outside Kiro ----------------
say "Step 4: start the server from the personal config and call core_list_projects (read only)"
cat > "$WORK/probe.js" <<'JS'
const { spawn } = require('child_process');
const s = require(process.argv[2]).mcpServers.ado;
const child = spawn(s.command, s.args, { env: { ...process.env, ...(s.env || {}) }, stdio: ['pipe', 'pipe', 'pipe'] });
let buf = '', err = '', done = false;
const send = (id, method, params) => child.stdin.write(JSON.stringify({ jsonrpc: '2.0', id, method, params }) + '\n');
const end = c => { done = true; clearTimeout(t); child.kill(); process.exit(c); };
const t = setTimeout(() => { console.log('RESULT: timeout'); end(2); }, 150000);
child.stderr.on('data', d => { err += d; });
child.on('exit', c => { if (!done) { console.log(`RESULT: server exited (code ${c}): ` + (err.match(/Error: .*/) || [''])[0]); process.exit(1); } });
child.stdout.on('data', d => { buf += d; let i;
  while ((i = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, i); buf = buf.slice(i + 1); let m; try { m = JSON.parse(line); } catch { continue; }
    if (m.id === 1) { console.log(`initialize -> ${m.result.serverInfo.name} ${m.result.serverInfo.version}`);
      child.stdin.write(JSON.stringify({ jsonrpc: '2.0', method: 'notifications/initialized' }) + '\n'); send(2, 'tools/list', {}); }
    else if (m.id === 2) { const n = (m.result?.tools || []).map(x => x.name); console.log(`tools/list -> ${n.length} tools: ${n.join(' ')}`);
      send(3, 'tools/call', { name: 'core_list_projects', arguments: {} }); }
    else if (m.id === 3) { if (m.error || m.result?.isError) { console.log('tools/call -> ERROR ' + JSON.stringify(m.error || m.result).slice(0, 300)); end(1); }
      const text = (m.result.content || []).map(c => c.text || '').join('');
      console.log('result header -> ' + text.split('\n')[0].replace(/<<[0-9a-f]+>>/g, '<<marker>>'));
      let list = []; try { list = JSON.parse(text.slice(text.indexOf('\n[') + 1, text.lastIndexOf(']') + 1)); } catch {}
      console.log(`tools/call core_list_projects -> ok, ${list.length} projects`);
      console.log(`project from config (ado_mcp_project) present: ${list.some(p => p.name === s.env?.ado_mcp_project)}`); end(0); } } });
send(1, 'initialize', { protocolVersion: '2024-11-05', capabilities: {}, clientInfo: { name: 'infios-caso04-demo', version: '1.0' } });
JS
node "$WORK/probe.js" "$USER_MCP" 2>&1 | tee "$WORK/probe.txt" | code
grep -q 'core_list_projects -> ok' "$WORK/probe.txt" || bad "the read-only MCP call did not succeed"

# --- Step 5: the SDLC agent calls the tool through Kiro ------------------------
say "Step 5: SDLC agent (kiro-cli chat --agent sdlc) calls core_list_projects"
if [ "${SKIP_AGENT:-0}" = 1 ]; then note "SKIP_AGENT=1: skipped"; else
  PROMPT='Call the MCP tool core_list_projects from the ado server exactly once, with no arguments. Do not call any other tool except tool_load if the tool is deferred. Then answer with exactly three lines: "TOOL: <tool name you called, or NONE>", "PROJECT_COUNT: <number of projects returned, or N/A>", "HAS_DEVELOPMENT_TOOLS: <yes|no|N/A>".'
  note "Command: kiro-cli chat --agent sdlc --no-interactive --trust-tools=mcp_ado_core_list_projects \"<prompt>\""
  note "Only that read-only tool is trusted, for this run only."
  # A session marker: only Kiro session files written after it belong to this run.
  touch "$WORK/session-marker"; sleep 1
  (cd "$REPO" && timeout 600 kiro-cli chat --agent sdlc --no-interactive \
      --trust-tools=mcp_ado_core_list_projects "$PROMPT") > "$WORK/agent.txt" 2>&1
  note "What the model answered (text only, NOT proof by itself):"
  sed 's/\x1b\[[0-9;]*m//g' "$WORK/agent.txt" | grep -E '^(TOOL|PROJECT_COUNT|HAS_DEVELOPMENT_TOOLS):' | code
  # Proof of execution comes from Kiro's own session record (messages.jsonl), written by the
  # Kiro Agent Server, not by the model: the tool_call event and the tool_result returned by
  # the ado MCP server. The project count in that result must match the independent call of Step 4.
  SESSION="$(find "$HOME/.kiro/sessions" -name messages.jsonl -newer "$WORK/session-marker" 2>/dev/null \
             | xargs -r grep -l -F 'exactly three lines' 2>/dev/null | head -1)"
  PROBE_COUNT="$(sed -n -E 's/.*core_list_projects -> ok, ([0-9]+) projects.*/\1/p' "$WORK/probe.txt")"
  if [ -z "$SESSION" ]; then
    bad "no Kiro session record was written for this run"
  else
    note "Kiro session record of this run: $(basename "$(dirname "$SESSION")")/messages.jsonl"
    node - "$SESSION" "${PROBE_COUNT:-}" "$WORK/agent.txt" > "$WORK/verify.txt" <<'JS'
const fs = require('fs');
const [file, probeCount, agentOut] = process.argv.slice(2);
const events = fs.readFileSync(file, 'utf8').trim().split('\n').map(l => { try { return JSON.parse(l).payload; } catch { return {}; } });
const call = events.find(p => p.type === 'tool_call' && p.actionType === 'mcp_ado_core_list_projects');
const result = call && events.find(p => p.type === 'tool_result' && p.toolCallId === call.toolCallId);
const text = typeof result?.content === 'string' ? result.content : '';
let list = null; try { list = JSON.parse(text.slice(text.indexOf('\n[') + 1, text.lastIndexOf(']') + 1)); } catch {}
const said = (fs.readFileSync(agentOut, 'utf8').replace(/\x1b\[[0-9;]*m/g, '').match(/^PROJECT_COUNT: (\d+)/m) || [])[1];
const checks = [
  ['tool_call event for @ado/core_list_projects', !!call, call ? `title=${call.title}, toolCallId=${call.toolCallId.slice(-8)}` : 'not found'],
  ['tool_call status is completed', call?.status === 'completed', call?.status || '-'],
  ['tool_result for that call, success=true', result?.success === true, result ? `success=${result.success}` : 'not found'],
  ['result comes from the ADO server (UNTRUSTED AZURE DEVOPS header)', text.includes('UNTRUSTED AZURE DEVOPS'), `${text.length} chars`],
  ['result is a non-empty JSON array of projects', Array.isArray(list) && list.length > 0, Array.isArray(list) ? `${list.length} projects` : 'not parseable'],
  ['count matches the independent call of Step 4', Array.isArray(list) && String(list.length) === probeCount, `step 4: ${probeCount || '-'}`],
  ['model reported the same count', said !== undefined && Array.isArray(list) && said === String(list.length), `model said: ${said ?? '-'}`],
];
for (const [name, ok, detail] of checks) console.log(`${ok ? 'OK  ' : 'FAIL'} ${name} (${detail})`);
process.exit(checks.every(c => c[1]) ? 0 : 1);
JS
    VERIFY_RC=$?
    code < "$WORK/verify.txt"
    [ "$VERIFY_RC" = 0 ] || bad "the Kiro session record does not prove a successful @ado/core_list_projects call"
  fi
  LOG="$(ls -td "$HOME"/.kiro/logs/*/ | head -1)"
  note "Kiro log of this run ($LOG):"
  grep -h -E '"serverName":"ado"' "$LOG/mcp.log" | grep -o -E '"message":"(mcp\.connect\.ok|mcp\.listTools\.ok|Failed to connect)"' | code
  grep -h -o -E 'acp.policy-eval.complete \{[^}]*\}' "$LOG/kiro.log" | sed 's/\\"/"/g' | code
fi

# --- Step 6: safety ---------------------------------------------------------------
say "Step 6: write tools are present but not approved automatically"
note "SDLC agent allowedTools with @ado: $(node -p "require('$REPO/.kiro/agents/sdlc.json').allowedTools.filter(t=>t.startsWith('@ado')).length")"
note "autoApprove in the personal config: $(node -p "(require('$USER_MCP').mcpServers.ado.autoApprove||[]).length")"
note "Write-capable tools offered by the server: $(grep -o 'tools: .*' "$WORK/probe.txt" | tr ' ' '\n' | grep -E '_write$|attachment_upload|attachment_link' | tr '\n' ' ')"

if [ "$FAILED" = 0 ]; then
  printf '\n\033[1;32mAFTER RESULT: the SDLC agent reaches Azure DevOps through the official MCP server, with your\n'
  printf 'Entra ID login, and a real read-only query succeeded.\033[0m\n'; exit 0
fi
printf '\n\033[1;31mAFTER RESULT: at least one check failed (see FAIL lines).\033[0m\n'; exit 1
