#!/usr/bin/env bash
# =============================================================================
# Infios Dev Portal - Case 09 (default Kiro region) - demonstration
#
# PHASE=before: .workspaceScripts/task_setupSdlc.sh as committed (Git HEAD), region us-east-1.
# PHASE=after : the working-tree file with the fix, region us-east-2.
#
# It runs the REAL Step 3 code of the setup script (the KIRO_* settings, the output
# helpers and the "Step 3/6: Kiro CLI Login" block, extracted from the file without
# editing it) against a MOCK kiro-cli, and shows the exact arguments that reach
# `kiro-cli login`.
#
# WHAT IS REAL AND WHAT IS A MOCK
#   REAL : bash running the extracted lines of task_setupSdlc.sh, unchanged.
#   MOCK : kiro-cli. A small bash script that records its arguments. It never opens a
#          browser, never contacts AWS and never reads or writes credentials.
# SAFETY
#   The extracted code runs under `env -i` with PATH = the sandbox only (bash and the
#   mock) and HOME = the sandbox, so the real kiro-cli and your real session are not
#   reachable. The script checks this before running and stops otherwise. It only
#   removes the sandbox it created.
# Exit code: 0 = every check gave the expected result, 1 = a check failed, 2 = setup.
# =============================================================================
set -uo pipefail

PHASE="after"
REPO="${REPO:-/workspaces/dev-portal}"
FILE=".workspaceScripts/task_setupSdlc.sh"
BAD=0

say()  { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
note() { printf '    %s\n' "$*"; }
code() { sed 's/^/      | /'; }
result() {  # result <PASS|FAIL> <check> <detail>
  local c='1;32'; [ "$1" = PASS ] || { c='1;31'; BAD=$((BAD + 1)); }
  printf "    \033[${c}m%-5s\033[0m %s (%s)\n" "$1" "$2" "$3"
}
check() { if [ "$1" = "$2" ]; then result PASS "$3" "$2"; else result FAIL "$3" "expected '$1', got '$2'"; fi; }

if [ "$PHASE" = before ]; then EXPECT="us-east-1"; else EXPECT="us-east-2"; fi

# --- Sandbox ----------------------------------------------------------------------------
SB="$(mktemp -d /tmp/infios-caso09-sandbox.XXXXXX)" || exit 2
case "$SB" in /tmp/infios-caso09-sandbox.?*) ;; *) echo "unexpected sandbox path"; exit 2;; esac
trap 'rm -rf -- "$SB"' EXIT   # removes only the sandbox created by this run
mkdir -p "$SB/bin" || exit 2
ln -s "$(command -v bash)" "$SB/bin/bash" || exit 2

{ printf '#!%s\n' "$SB/bin/bash"; cat <<'MOCK'; } > "$SB/bin/kiro-cli"
# MOCK kiro-cli for the Case 09 demo: records its arguments, contacts nothing.
printf 'kiro-cli' >> "$MOCK_LOG"; printf ' %s' "$@" >> "$MOCK_LOG"; printf '\n' >> "$MOCK_LOG"
case "$1" in
  whoami) [ -f "$MOCK_STATE" ] ;;                  # logged in only after a mock login
  login)  [ "$MOCK_LOGIN" = ok ] && : > "$MOCK_STATE"; [ "$MOCK_LOGIN" = ok ] ;;
  *)      exit 99 ;;
esac
MOCK
chmod +x "$SB/bin/kiro-cli" || exit 2

# --- Step 0: source file and safety checks ---------------------------------------------------
say "Step 0 ($PHASE): source file and safety checks"
if [ "$PHASE" = before ]; then
  git --no-optional-locks -C "$REPO" show "HEAD:$FILE" > "$SB/setup.sh" || exit 2; SRC="Git HEAD (original)"
else
  cp "$REPO/$FILE" "$SB/setup.sh" || exit 2; SRC="working tree (with the fix)"
fi
note "Script under test: $FILE from the $SRC"
SENV=(env -i PATH="$SB/bin" HOME="$SB")
check "$SB/bin/kiro-cli" "$("${SENV[@]}" "$SB/bin/bash" -c 'type -a -p kiro-cli')" "inside the sandbox, every kiro-cli on PATH is the mock"
check "$SB" "$("${SENV[@]}" "$SB/bin/bash" -c 'printf %s "$HOME"')" "HOME is the sandbox (real Kiro session files not reachable)"
check 0 "$(grep -c -E '/usr/|/home/|\.aws|\.kiro|curl|https?:' "$SB/bin/kiro-cli")" "the mock references no real binary, credential path or URL"
[ "$BAD" -eq 0 ] || { echo "Safety preconditions failed: nothing was run."; exit 2; }

# --- The real lines -------------------------------------------------------------------------
say "Real lines of the script (line numbers of the $SRC)"
grep -n -E '^KIRO_(IDENTITY_PROVIDER|REGION)=' "$SB/setup.sh" | code
S3="$(grep -n -F 'step "Step 3/6: Kiro CLI Login"' "$SB/setup.sh" | cut -d: -f1)"
S4="$(grep -n -F 'step "Step 4/6: SDLC Framework Install"' "$SB/setup.sh" | cut -d: -f1)"
[ -n "$S3" ] && [ -n "$S4" ] || { result FAIL "find the Step 3 block" "markers not found"; exit 1; }
# The block ends just before the '# ====' banner that introduces Step 4.
END="$(awk -v a="$S3" 'NR > a && /^# =+$/ {print NR - 1; exit}' "$SB/setup.sh")"
note "Step 3 block: lines $S3-$END"
awk -v a="$S3" -v b="$END" 'NR >= a && NR <= b {printf "%6d\t%s\n", NR, $0}' "$SB/setup.sh" | code

# Harness = line 2 (set -e) + the KIRO_* settings + the output helpers + the Step 3 block,
# all copied from the file under test, in the same order.
{ echo '#!/usr/bin/env bash'
  sed -n '2p' "$SB/setup.sh"
  grep -E '^KIRO_(IDENTITY_PROVIDER|REGION)=' "$SB/setup.sh"
  grep -E '^(GREEN|YELLOW|RED|NC)=|^(info|warn|error|step)\(\) ' "$SB/setup.sh"
  sed -n "${S3},${END}p" "$SB/setup.sh"; } > "$SB/step3.sh"

# run_case <name> <ok|fail|logged-in>: runs the extracted Step 3 with the mock
run_case() {
  local log="$SB/$1.log" state="$SB/$1.state" mode="$2"
  : > "$log"; rm -f -- "$state"; [ "$mode" = logged-in ] && : > "$state"
  "${SENV[@]}" MOCK_LOG="$log" MOCK_STATE="$state" MOCK_LOGIN="${mode/logged-in/ok}" \
    "$SB/bin/bash" "$SB/step3.sh" > "$SB/$1.out" 2>&1
  RC=$?
  note "Terminal output:"; sed 's/\x1b\[[0-9;]*m//g' "$SB/$1.out" | code
  note "Calls received by the mock kiro-cli:"; code < "$log"
  LOGIN="$(grep '^kiro-cli login' "$log")"
}

say "Case 1: not logged in, login succeeds"
run_case c1 ok
check 0 "$RC" "Step 3 finishes with exit code 0"
check 1 "$(printf '%s\n' "$LOGIN" | grep -c .)" "kiro-cli login is called once"
check "$EXPECT" "$(printf '%s\n' "$LOGIN" | sed -n 's/.* --region \([^ ]*\).*/\1/p')" "region passed to kiro-cli login"
check "kiro-cli login --license pro --identity-provider https://d-9a671a9ffc.awsapps.com/start --region $EXPECT --use-device-flow" \
  "$LOGIN" "complete login command (other arguments unchanged)"

say "Case 2: not logged in, login does not complete"
run_case c2 fail
check 0 "$RC" "Step 3 only warns (exit code 0)"
HINT="$(sed 's/\x1b\[[0-9;]*m//g' "$SB/c2.out" | grep -E '^ +kiro-cli login' | sed 's/^ *//')"
check "$LOGIN" "$HINT" "the printed 'run it later' command is the same one, with --region $EXPECT"

say "Case 3: already logged in"
run_case c3 logged-in
check 0 "$(grep -c '^kiro-cli login' "$SB/c3.log")" "no login is attempted"

if [ "$PHASE" = after ]; then
  say "What changed in the file (read-only, git diff against HEAD)"
  HUNKS="$(git --no-optional-locks -C "$REPO" diff -U0 HEAD -- "$FILE" | grep '^@@')"
  note "Changed areas (hunk headers):"; printf '%s\n' "$HUNKS" | code
  REG="$(git --no-optional-locks -C "$REPO" diff -U0 HEAD -- "$FILE" | grep -E '^[-+]KIRO_REGION=')"
  note "Region lines:"; printf '%s\n' "$REG" | code
  check '-KIRO_REGION="us-east-1"|+KIRO_REGION="us-east-2"' "$(printf '%s\n' "$REG" | paste -sd '|')" "line 18: us-east-1 replaced by us-east-2"
  check 1 "$(printf '%s\n' "$HUNKS" | grep -c '^@@ -18 +18 @@')" "the region change is a one-line change at line 18"
  check 2 "$(printf '%s\n' "$HUNKS" | grep -c .)" "only two changed areas: line 18 (this case) and the UIKit block (Case 05)"
  check 1 "$(grep -c -F 'us-east' "$REPO/$FILE")" "no other region in the script"
fi

say "Result"
if [ "$BAD" -ne 0 ]; then printf '\n\033[1;31m%s RESULT: %d check(s) failed.\033[0m\n' "${PHASE^^}" "$BAD"; exit 1; fi
if [ "$PHASE" = before ]; then
  printf '\n\033[1;33mBEFORE RESULT: the original script sends --region us-east-1 to kiro-cli login\n'
  printf '(and prints it in the retry hint). Mock kiro-cli, real script lines.\033[0m\n'
else
  printf '\n\033[1;32mAFTER RESULT: the corrected script sends --region us-east-2 to kiro-cli login; every other\n'
  printf 'argument and branch is unchanged. Mock kiro-cli, real script lines.\033[0m\n'
fi
exit 0
