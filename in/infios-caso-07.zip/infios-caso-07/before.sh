#!/usr/bin/env bash
# =============================================================================
# Infios Dev Portal - Case 07 (exit code 137 when stopping Dozzle) - demonstration
#
# PHASE=before: how a 137 appears when the Dozzle task is stopped (forced second
#               Ctrl+C, or a container that ignores SIGTERM until the stop timeout).
# PHASE=after : the normal stop (one Ctrl+C, Dozzle handles SIGTERM) and a read-only
#               check that no repository change was needed.
#
# WHAT IS REAL AND WHAT IS A MOCK
#   REAL : bash 5 running an exact copy of .workspaceScripts/task_dozzle.sh, and the
#          SIGINT that a terminal sends to the whole foreground process group on Ctrl+C.
#   MOCK : the `docker` command. It is a small bash script in a throw-away sandbox that
#          prints what Docker Compose v5.6.1 prints and returns the exit codes its source
#          code returns (pkg/compose/up.go: runEventLoop, killApplication, stopOnFirstExit).
#          It never contacts a Docker daemon.
#
# SAFETY
#   The task copy runs under `env -i` with PATH containing ONLY the sandbox (bash,
#   dirname, sleep and the mock). The real docker binary is not on that PATH, HOME is
#   the sandbox (no Docker contexts) and DOCKER_HOST points to a socket that does not
#   exist. The script checks all of that before running anything and stops otherwise.
#   This harness itself never runs docker. It only removes the sandbox it created.
# Exit code: 0 = every check gave the expected result, 1 = a check failed, 2 = setup.
# =============================================================================
set -uo pipefail

PHASE="before"
REPO="${REPO:-/workspaces/dev-portal}"
TASK_REL=".workspaceScripts/task_dozzle.sh"
COMPOSE_REL="docker-compose-dozzle.yml"
STOP_TIMEOUT=10            # Docker's default stop timeout (no stop_grace_period / -t is set)
BAD=0

say()  { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
note() { printf '    %s\n' "$*"; }
code() { sed 's/^/      | /'; }
result() {  # result <PASS|FAIL> <check> <detail>
  local c='1;32'; [ "$1" = PASS ] || { c='1;31'; BAD=$((BAD + 1)); }
  printf "    \033[${c}m%-5s\033[0m %s (%s)\n" "$1" "$2" "$3"
}
check() { if [ "$1" = "$2" ]; then result PASS "$3" "$2"; else result FAIL "$3" "expected $1, got $2"; fi; }

# --- Sandbox -----------------------------------------------------------------------
SB="$(mktemp -d /tmp/infios-caso07-sandbox.XXXXXX)" || exit 2
case "$SB" in /tmp/infios-caso07-sandbox.?*) ;; *) echo "unexpected sandbox path"; exit 2;; esac
trap 'rm -rf -- "$SB"' EXIT   # removes only the sandbox created by this run
mkdir -p "$SB/bin" "$SB/repo/.workspaceScripts" || exit 2
for t in bash dirname sleep; do ln -s "$(command -v "$t")" "$SB/bin/$t" || exit 2; done
cp "$REPO/$TASK_REL" "$SB/repo/$TASK_REL" && cp "$REPO/$COMPOSE_REL" "$SB/repo/$COMPOSE_REL" || exit 2

{ printf '#!%s\n' "$SB/bin/bash"; cat <<'MOCK'; } > "$SB/bin/docker"
# MOCK docker CLI for the Case 07 demo. Never contacts a Docker daemon.
# Models Docker Compose v5.6.1 attached `up` (pkg/compose/up.go):
#   1st SIGINT -> "Gracefully Stopping..." and stop: SIGTERM, then SIGKILL after the timeout
#   2nd SIGINT -> killApplication: SIGKILL
#   container exit with --abort-on-container-exit -> stopOnFirstExit: up returns that exit code
log() { printf '%s\n' "$*" >> "$MOCK_LOG"; }
log "mock docker called: $*"
case " $* " in
  *" compose "*" down "*|*" compose "*" down")
    log "compose down: removes container k1-dozzle-1 (named volume dozzle_data kept)"
    echo " Container k1-dozzle-1  Removed"; exit 0 ;;
  *" compose "*" up "*) ;;
  *) log "unsupported mock call"; exit 99 ;;
esac
abort=0; case " $* " in *" --abort-on-container-exit "*) abort=1 ;; esac
echo "Attaching to k1-dozzle-1"
echo "k1-dozzle-1  | (mock) Dozzle listening on :8080"
ints=0; stopping=0; ticks=0   # one tick = one 0.2 s loop step
finish() {
  echo "k1-dozzle-1 exited with code $1"; log "container k1-dozzle-1 exit code $1"
  if [ "$abort" = 1 ]; then
    echo "Aborting on container exit..."
    log "compose up returns $1 (stopOnFirstExit records the container exit code)"; exit "$1"
  fi
  exit 0
}
on_signal() {
  ints=$((ints + 1)); log "compose up received SIGINT #$ints"
  if [ "$ints" -eq 1 ]; then
    echo " Gracefully Stopping... press Ctrl+C again to force"
    echo " Container k1-dozzle-1  Stopping"
    log "compose stop: SIGTERM to k1-dozzle-1, SIGKILL after ${MOCK_STOP_TIMEOUT}s"; stopping=1; ticks=0
  else
    log "compose kill (second signal): SIGKILL to k1-dozzle-1"; finish 137
  fi
}
trap on_signal INT TERM
while :; do
  if [ "$stopping" = 1 ]; then
    ticks=$((ticks + 1))
    # handled: exits ~1 s after SIGTERM, matching the recorded v11.4.1 stops (kill -> die within 1 s)
    if [ "$MOCK_SIGTERM" = handled ] && [ "$ticks" -ge 5 ]; then log "container handled SIGTERM and exited"; finish 0; fi
    if [ "$ticks" -ge $((MOCK_STOP_TIMEOUT * 5)) ]; then log "stop timeout reached: SIGKILL"; finish 137; fi
  fi
  sleep 0.2
done
MOCK
chmod +x "$SB/bin/docker" || exit 2

# --- Step 0: safety preconditions --------------------------------------------------------
say "Step 0 ($PHASE): sandbox and safety checks"
SENV=(env -i PATH="$SB/bin" HOME="$SB" DOCKER_HOST="unix://$SB/no-daemon.sock")
note "Sandbox: $SB"
note "Sandbox PATH contents: $(cd "$SB/bin" && echo *)"
RESOLVED="$("${SENV[@]}" "$SB/bin/bash" -c 'type -a -p docker')"
check "$SB/bin/docker" "$RESOLVED" "inside the sandbox, every 'docker' on PATH is the mock"
check "absent" "$([ -e "$SB/no-daemon.sock" ] && echo present || echo absent)" "DOCKER_HOST socket of the sandbox does not exist"
check "0" "$(grep -c -E '/usr/|/var/run|docker\.sock' "$SB/bin/docker")" "the mock references no real binary or socket"
cmp -s "$REPO/$TASK_REL" "$SB/repo/$TASK_REL" && result PASS "task script copy is byte-identical to the repository" "$(sha256sum "$REPO/$TASK_REL" | cut -c1-16)" \
  || result FAIL "task script copy is byte-identical to the repository" "differs"
[ "$BAD" -eq 0 ] || { echo "Safety preconditions failed: nothing was run."; exit 2; }

# --- Read-only facts from the repository ---------------------------------------------------
say "Repository facts (read-only)"
note "$TASK_REL:"; cat -n "$REPO/$TASK_REL" | code
note "Stop timeout settings in $COMPOSE_REL or the task (stop_grace_period, -t, --timeout):"
TO="$(grep -n -E 'stop_grace_period|stop_signal| -t |--timeout' "$REPO/$COMPOSE_REL" "$REPO/$TASK_REL")"
printf '%s\n' "${TO:-none -> Docker default: SIGTERM, then SIGKILL after ${STOP_TIMEOUT}s}" | code

# --- Scenario runner --------------------------------------------------------------------------
# run_scenario <name> <handled|ignored> <ctrl-c presses>
run_scenario() {
  local name="$1" beh="$2" presses="$3" out="$SB/$1.out" log="$SB/$1.log" pid rc i
  : > "$log"
  set -m   # job control: the task runs in its own process group, like a terminal's foreground job
  "${SENV[@]}" MOCK_LOG="$log" MOCK_SIGTERM="$beh" MOCK_STOP_TIMEOUT="$STOP_TIMEOUT" \
    "$SB/bin/bash" "$SB/repo/$TASK_REL" > "$out" 2>&1 &
  pid=$!
  set +m
  for i in $(seq 1 50); do grep -q 'Attaching to' "$out" 2>/dev/null && break; sleep 0.1; done
  T0=$SECONDS
  kill -INT -- "-$pid"; echo "harness: Ctrl+C #1 (SIGINT to process group $pid)" >> "$log"
  if [ "$presses" -ge 2 ]; then sleep 0.5; kill -INT -- "-$pid"; echo "harness: Ctrl+C #2" >> "$log"; fi
  wait "$pid"; rc=$?
  ELAPSED=$((SECONDS - T0)); TASK_RC=$rc
  note "Terminal output of the task (mock Compose lines):"; code < "$out"
  note "What happened, in order (mock log):"; code < "$log"
  note "Exit status of task_dozzle.sh: $rc   (time from first Ctrl+C: ${ELAPSED}s)"
  UP_RC="$(sed -n 's/^compose up returns \([0-9]*\).*/\1/p' "$log" | tail -1)"
  CTR_RC="$(sed -n 's/^container k1-dozzle-1 exit code \([0-9]*\)$/\1/p' "$log" | tail -1)"
  DOWN_RAN="$(grep -c '^mock docker called: compose -f ./docker-compose-dozzle.yml down$' "$log")"
}

if [ "$PHASE" = before ]; then
  say "Scenario B1: Ctrl+C twice (the second press forces the stop)"
  run_scenario b1 handled 2
  check 137 "$CTR_RC" "container exit code after the forced stop (128 + 9, SIGKILL)"
  check 137 "${UP_RC:-none}" "'docker compose up' (task line 6) returns the container's code"
  check 1 "$DOWN_RAN" "bash continues to task line 7 ('down' removes the container)"
  check 0 "$TASK_RC" "the task's own exit status is the status of line 7, not 137"

  say "Scenario B2: Ctrl+C once, but the container ignores SIGTERM (stop timeout ${STOP_TIMEOUT}s)"
  note "Hypothetical: the Dozzle image in use handles SIGTERM (see the HTML). This shows the timeout path."
  run_scenario b2 ignored 1
  check 137 "$CTR_RC" "container exit code when the stop timeout expires"
  [ "$ELAPSED" -ge "$STOP_TIMEOUT" ] && result PASS "SIGKILL only after the timeout" "${ELAPSED}s >= ${STOP_TIMEOUT}s" \
    || result FAIL "SIGKILL only after the timeout" "${ELAPSED}s"
  check 137 "${UP_RC:-none}" "'docker compose up' returns 137"
  check 1 "$DOWN_RAN" "task line 7 ('down') still runs"
  check 0 "$TASK_RC" "the task's own exit status is 0"
else
  say "Scenario A1: Ctrl+C once, Dozzle handles SIGTERM (as recorded for v11.4.1: signal=15 -> exitCode=0 within 1s)"
  run_scenario a1 handled 1
  check 0 "$CTR_RC" "container exit code after a normal stop"
  check 0 "${UP_RC:-none}" "'docker compose up' (task line 6) returns 0"
  check 0 "$(grep -c '137' "$SB/a1.out")" "no '137' in the terminal output"
  check 1 "$DOWN_RAN" "task line 7 ('down') removes the stopped container"
  check 0 "$TASK_RC" "the task's own exit status"

  say "No repository change was needed (read-only)"
  git --no-optional-locks -C "$REPO" diff --quiet HEAD -- "$TASK_REL" .vscode/tasks.json \
    && result PASS "task_dozzle.sh and tasks.json are identical to Git HEAD" "no change made" \
    || result FAIL "task_dozzle.sh and tasks.json are identical to Git HEAD" "they differ"
  grep -q -x '      - "dozzle_data:/data"' "$REPO/$COMPOSE_REL" && result PASS "Case 06 volume line still present" "dozzle_data:/data" \
    || result FAIL "Case 06 volume line still present" "missing"
fi

say "Result"
check 0 "$(grep -h -c -v -E '^(mock docker called: compose -f \./docker-compose-dozzle\.yml (up --abort-on-container-exit|down)|compose |container |stop timeout|harness: )' "$SB"/*.log | awk '{s+=$1} END {print s+0}')" "the mock saw only the two task calls (no other docker command)"
if [ "$BAD" -ne 0 ]; then printf '\n\033[1;31m%s RESULT: %d check(s) failed.\033[0m\n' "${PHASE^^}" "$BAD"; exit 1; fi
if [ "$PHASE" = before ]; then
  printf '\n\033[1;33mBEFORE RESULT: 137 is the CONTAINER exit code (SIGKILL) when the stop is forced or times out.\n'
  printf 'Compose propagates it from `up`; the task then runs `down` and exits 0. Simulated Docker, real bash.\033[0m\n'
else
  printf '\n\033[1;32mAFTER RESULT: one Ctrl+C stops Dozzle cleanly (exit code 0, no 137). Expected behaviour,\n'
  printf 'no repository change needed. Simulated Docker, real bash.\033[0m\n'
fi
exit 0
