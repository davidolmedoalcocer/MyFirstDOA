#!/usr/bin/env bash
# =============================================================================
# Infios Dev Portal - Case 01 (EACCES in node_modules) - BEFORE the fix
# Real applications: adminUi, tenantUi and sharedUIComponents.
#
# Uses the ORIGINAL docker-compose-devui.yml from Git (no `user:` on the UI services).
#
# REAL parts:
#   - Compose file: the original file from Git, unmodified.
#   - UI images: built by that file from adminUi/Dockerfile.dev and tenantUi/Dockerfile.dev.
#   - Code: every Git-tracked file of adminUi, tenantUi and sharedUIComponents.
#   - Dependencies: the real lockfiles, installed from a copy of the Dev Container's real
#     pnpm store (offline, so no credentials are needed or used).
#   - The Dev Container step runs in the real Dev Container image, as the Dev Container
#     user, with the same command as .workspaceScripts/task_startDevPortalDevUI.sh.
#   - The UIs are started with their real CMD (pnpm dev --host) and must answer HTTP.
#
# DELIBERATE PREPARATION (not a proven historical cause):
#   - Step 3 runs `pnpm install` INSIDE the UI containers. Today's Dockerfile.dev does not
#     do that (its ENTRYPOINT did until 2026-03-31). It recreates the incident's condition:
#     root-owned node_modules/.bin and node_modules/@tsconfig/node22. The process that
#     created the root-owned files in the real incident was never identified.
#   - A temporary volume replaces the real workspace volume, and an override renames the
#     containers and removes published ports so nothing clashes with the running ones.
#
# SAFETY: creates only resources named infios-caso01-real-before*, never mounts the real
# workspace volume, only reads the repository and the pnpm store, never copies ~/.npmrc,
# and removes only its own resources on exit (KEEP=1 keeps them for inspection).
# Run it from a terminal inside the Infios Dev Portal Dev Container. Do not run it at the
# same time as after.sh.
# =============================================================================
set -uo pipefail

PHASE="before"
REPO="${REPO:-/workspaces/dev-portal}"
STORE_SRC="${STORE_SRC:-/workspaces/.pnpm-store}"       # real pnpm store, read only
ORIGINAL_REF="${ORIGINAL_REF:-HEAD}"                     # Git revision with the original compose file
PROJECT="infios-caso01-real-${PHASE}"
VOLUME="${PROJECT}-vol"                                  # stands in for devcontainer_workspace
SERVICES=(dev-portal-admin-ui dev-portal-tenant-ui)
APPS=(sharedUIComponents adminUi tenantUi)               # same order as Dev: Start UI
DEV_USER="$(id -u):$(id -g)"                             # Dev Container user (node, normally 1000:1000)
WORK="$(mktemp -d "/tmp/${PROJECT}.XXXXXX")"
COMPOSE_FILE="$WORK/docker-compose-devui.original.yml"

say()  { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
note() { printf '    %s\n' "$*"; }
fail() { printf '\n\033[1;31mERROR: %s\033[0m\n' "$*" >&2; exit 2; }

compose() {  # real compose file + safety override, temporary env file, repo as project directory
  docker compose -p "$PROJECT" --project-directory "$REPO" --env-file "$WORK/demo.env" \
    -f "$COMPOSE_FILE" -f "$WORK/override.yml" "$@"
}

# Run a command with the given image, user and mount; its output goes to a log in the
# volume and is printed from there (output written after pnpm exits can be lost when it is
# read straight from `docker run`).
in_volume() {  # in_volume <image> <user> <mount point> <workdir> <command>
  local image=$1 user=$2 mnt=$3 wd=$4 cmd=$5 log=".demo/step-$RANDOM.log"
  docker run --rm --user "$user" -e HOME=/tmp/home -v "$VOLUME:$mnt" -w "$wd" \
    --entrypoint sh "$image" -c "( $cmd ) > $mnt/$log 2>&1"
  local rc=$?
  docker run --rm --user 0 -v "$VOLUME:/v" --entrypoint cat "$UI_IMAGE" "/v/$log"
  return $rc
}

ownership_report() {  # owners of the paths from the original error, and foreign-owned counts
  in_volume "$UI_IMAGE" 0 /app /app/dev-portal "
    for p in sharedUIComponents/node_modules/.bin adminUi/node_modules/@tsconfig/node22 \
             tenantUi/node_modules/@tsconfig/node22 adminUi/node_modules/.vite tenantUi/node_modules/.vite; do
      [ -e \"\$p\" ] && stat -c '    %u:%g  %n' \"\$p\"
    done
    for d in ${APPS[*]}; do
      [ -d \$d/node_modules ] || continue
      echo \"    \$d/node_modules: root-owned=\$(find \$d/node_modules -user 0 | wc -l)  not-owned-by-${DEV_USER%%:*}=\$(find \$d/node_modules ! -user ${DEV_USER%%:*} | wc -l)\"
    done"
}

snapshot() {  # read-only fingerprint of the real environment
  {
    docker ps -a --format '{{.ID}} {{.Names}} {{.State}}' | grep -v infios-caso01 | sort
    docker ps -q | xargs -r docker inspect -f '{{.Name}} {{.State.StartedAt}} {{.Config.User}}' | grep -v infios-caso01 | sort
    docker volume ls -q | grep -v infios-caso01 | sort
    git -C "$REPO" branch --show-current
    git -C "$REPO" status --porcelain
    git -C "$REPO" diff | sha256sum
    sha256sum "$REPO/.env" "$HOME/.npmrc" 2>/dev/null
    for d in "${APPS[@]}"; do
      stat -c '%Y %u:%g %n' "$REPO/$d/node_modules" "$REPO/$d/node_modules/.modules.yaml"
      echo "$d root-owned=$(find "$REPO/$d/node_modules" -user 0 2>/dev/null | wc -l)"
    done
    du -s "$STORE_SRC" 2>/dev/null
  } > "$1" 2>&1
}

cleanup() {
  local rc=$?
  if [ "${KEEP:-0}" = "1" ]; then
    say "KEEP=1: keeping project $PROJECT, volume $VOLUME and $WORK for inspection"; exit $rc
  fi
  if [ -n "${CLEANUP_READY:-}" ]; then
    compose down --remove-orphans >/dev/null 2>&1                  # this demo's project only
    docker volume rm "$VOLUME" >/dev/null 2>&1
    docker image rm "${PROJECT}-dev-portal-admin-ui" "${PROJECT}-dev-portal-tenant-ui" >/dev/null 2>&1
  fi
  rm -rf "$WORK"
  exit $rc
}

# --- Step 0: preconditions and environment fingerprint -----------------------
say "Step 0: preconditions"
command -v docker >/dev/null || fail "docker is not available"
git -C "$REPO" rev-parse --git-dir >/dev/null 2>&1 || fail "$REPO is not a Git repository"
[ -d "$STORE_SRC/v10" ] || fail "real pnpm store not found at $STORE_SRC/v10"
DC_IMAGE="${DC_IMAGE:-$(docker inspect -f '{{.Config.Image}}' "$(hostname)" 2>/dev/null)}"
[ -n "$DC_IMAGE" ] || fail "cannot find the Dev Container image; run this inside the Dev Container or set DC_IMAGE"
[ -z "$(docker ps -aq --filter "name=^${PROJECT}")" ] || fail "containers named ${PROJECT}* already exist; remove them first"
docker volume inspect "$VOLUME" >/dev/null 2>&1 && fail "volume $VOLUME already exists; remove it first"
trap cleanup EXIT
snapshot "$WORK/env-start.txt"
note "Dev Container image: $DC_IMAGE"
note "Dev Container user:  $(id)"
note "Real environment fingerprint saved (containers, volumes, Git, .env, ~/.npmrc, node_modules, pnpm store)."

# --- Step 1: the original configuration --------------------------------------
say "Step 1: ORIGINAL docker-compose-devui.yml from Git ($ORIGINAL_REF)"
git -C "$REPO" show "$ORIGINAL_REF:docker-compose-devui.yml" > "$COMPOSE_FILE" \
  || fail "cannot read docker-compose-devui.yml at $ORIGINAL_REF"
grep -q 'user:' "$COMPOSE_FILE" && fail "the file at $ORIGINAL_REF has a user: line; it is not the original"
sed -n '/^services:/,$p' "$COMPOSE_FILE" | grep -v '^ *#' | sed 's/^/      /'
# Safety override: only renames the containers and removes the published ports.
{
  echo "services:"
  for s in "${SERVICES[@]}"; do printf '  %s:\n    container_name: %s-%s\n    ports: !reset []\n' "$s" "$PROJECT" "${s#dev-portal-}"; done
} > "$WORK/override.yml"
printf 'DEVCONTAINER_VOLUME=%s\n' "$VOLUME" > "$WORK/demo.env"   # the external volume -> temporary volume
for s in "${SERVICES[@]}"; do
  u="$(compose config "$s" 2>/dev/null | awk '/^ *user:/{print $2}' | tr -d "'\"")"
  note "Docker Compose resolves user for $s: '${u}' (empty = image default)"
done

# --- Step 2: real images, real code, real dependency store -------------------
say "Step 2: build the real UI images and copy the real code and pnpm store to a temporary volume"
compose build >"$WORK/build.log" 2>&1 || { tail -20 "$WORK/build.log"; fail "image build failed"; }
CLEANUP_READY=1
UI_IMAGE="${PROJECT}-dev-portal-admin-ui"
for s in "${SERVICES[@]}"; do
  note "Image ${PROJECT}-$s default user: '$(docker image inspect -f '{{.Config.User}}' "${PROJECT}-$s")' (empty = root)"
done
docker volume create "$VOLUME" >/dev/null || fail "cannot create volume $VOLUME"
docker run --rm --user 0 -v "$VOLUME:/v" --entrypoint sh "$UI_IMAGE" -c \
  "mkdir -p /v/dev-portal /v/.demo && chown $DEV_USER /v /v/dev-portal && chmod 1777 /v/.demo" \
  || fail "cannot prepare $VOLUME"
# Only Git-tracked files: no node_modules, no build output, no untracked local files.
git -C "$REPO" ls-files -z "${APPS[@]}" | tar -C "$REPO" --null -T - -cf - \
  | docker run --rm -i --user "$DEV_USER" -v "$VOLUME:/v" -w /v/dev-portal --entrypoint tar "$UI_IMAGE" -xf - \
  || fail "cannot copy the application code"
note "Copied $(git -C "$REPO" ls-files "${APPS[@]}" | wc -l) tracked files of ${APPS[*]} (owner $DEV_USER)."
tar -C "$(dirname "$STORE_SRC")" -cf - "$(basename "$STORE_SRC")" \
  | docker run --rm -i --user "$DEV_USER" -v "$VOLUME:/v" -w /v --entrypoint tar "$UI_IMAGE" -xf - \
  || fail "cannot copy the pnpm store"
note "Copied the real pnpm store ($(du -sh "$STORE_SRC" | cut -f1)) to the volume root, where pnpm looks for it."
note "Volume layout: /dev-portal/{${APPS[*]}} and /.pnpm-store, the same as the real workspace volume."
note "Mounted at /workspaces in the Dev Container and at /app in the UI containers (as in the real setup)."

# --- Step 3: DELIBERATE PREPARATION - install inside the UI containers -------
say "Step 3: DELIBERATE PREPARATION - pnpm install inside the UI containers, with the original user"
note "This recreates the incident's condition on purpose. It is not the proven historical cause."
compose run --rm --no-deps -w /app/dev-portal "${SERVICES[0]}" sh -c \
  '( echo "    UI container user: $(id)"
     for d in sharedUIComponents adminUi; do pnpm -C $d install --frozen-lockfile --offline >/tmp/l 2>&1; echo "    $d: pnpm install exit code $?"; done
   ) > /app/.demo/ui-install-admin.log 2>&1' >/dev/null 2>&1
docker run --rm --user 0 -v "$VOLUME:/v" --entrypoint cat "$UI_IMAGE" /v/.demo/ui-install-admin.log
compose run --rm --no-deps "${SERVICES[1]}" sh -c \
  '( echo "    UI container user: $(id)"; pnpm install --frozen-lockfile --offline >/tmp/l 2>&1; echo "    tenantUi: pnpm install exit code $?"
   ) > /app/.demo/ui-install-tenant.log 2>&1' >/dev/null 2>&1
docker run --rm --user 0 -v "$VOLUME:/v" --entrypoint cat "$UI_IMAGE" /v/.demo/ui-install-tenant.log
ownership_report

# --- Step 4: the real Dev: Start UI install, as the Dev Container user -------
say "Step 4: Dev Container user ($DEV_USER) runs the install of task_startDevPortalDevUI.sh"
note "Command: pnpm -C <dir> install --frozen-lockfile, plus --offline (no network or credentials),"
note "--reporter=append-only and --config.confirm-modules-purge=false (answer yes without a terminal)."
note "pnpm recreates node_modules because the UI container recorded its own store path (/app/.pnpm-store)."
in_volume "$DC_IMAGE" "$DEV_USER" /workspaces /workspaces/dev-portal "
  echo \"    Dev Container user: \$(id)\"
  for d in ${APPS[*]}; do
    pnpm -C \$d install --frozen-lockfile --offline --reporter=append-only --config.confirm-modules-purge=false > /tmp/\$d.log 2>&1
    rc=\$?; echo \"    \$d: pnpm install exit code \$rc\"
    grep -m1 -E 'EACCES|ERR_PNPM' /tmp/\$d.log | sed 's/^/      /'
    echo \$rc >> /tmp/rcs
  done
  ! grep -qv '^0\$' /tmp/rcs"
DEV_RC=$?
note "The real task stops here (set -e): the UI containers would not even be started."

# --- Step 5: real applications with the real CMD, original user --------------
say "Step 5: start the real UIs with their real CMD (pnpm dev --host) to show who they run as"
compose up -d --no-deps "${SERVICES[@]}" >/dev/null 2>&1 || fail "cannot start the UI services"
APP_OK=1
for pair in "admin-ui:/devportal/adminui/" "tenant-ui:/devportal/tenantui/"; do
  c="${PROJECT}-${pair%%:*}"; base="${pair#*:}"; ok=""
  for _ in $(seq 1 60); do docker exec "$c" wget -q -O /dev/null "http://127.0.0.1${base}" 2>/dev/null && { ok=1; break; }; sleep 1; done
  if [ -n "$ok" ] && docker exec "$c" wget -q -O /dev/null "http://127.0.0.1${base}src/main.ts" 2>/dev/null; then
    note "$c: HTTP OK for ${base} and ${base}src/main.ts (Vite compiled the real entry point); process user: $(docker exec "$c" id -un 2>/dev/null) ($(docker exec "$c" id -u):$(docker exec "$c" id -g))"
    docker top "$c" -o pid,uid,gid,args 2>/dev/null | awk 'NR==1 || /vite.js/' | sed 's/^/      docker top: /'
  else
    APP_OK=0; note "$c: did NOT answer"; docker logs --tail 15 "$c" 2>&1 | sed 's/^/      /'
  fi
done
sleep 3
compose stop >/dev/null 2>&1
ownership_report

# --- Step 6: result and check of the real environment ------------------------
say "Step 6: result"
snapshot "$WORK/env-end.txt"
if diff -q "$WORK/env-start.txt" "$WORK/env-end.txt" >/dev/null; then
  note "Real environment unchanged (containers, volumes, Git, .env, ~/.npmrc, node_modules, pnpm store)."
  ENV_OK=1
else
  ENV_OK=0; note "WARNING: the real environment fingerprint changed:"
  diff "$WORK/env-start.txt" "$WORK/env-end.txt" | sed 's/^/      /'
fi
if [ "$DEV_RC" -ne 0 ] && [ "$APP_OK" = 1 ] && [ "$ENV_OK" = 1 ]; then
  printf '\n\033[1;31mBEFORE RESULT: EACCES reproduced with the real apps. The UI containers run as root under the\n'
  printf 'original compose file, node_modules ends up root-owned, and the Dev Container user (%s)\n' "$DEV_USER"
  printf 'cannot recreate it.\033[0m\n'
  exit 0
fi
printf '\n\033[1;33mBEFORE RESULT: NOT as expected (pnpm rc=%s, apps ok=%s, environment ok=%s).\033[0m\n' "$DEV_RC" "$APP_OK" "$ENV_OK"
exit 1
