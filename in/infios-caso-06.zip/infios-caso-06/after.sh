#!/usr/bin/env bash
# =============================================================================
# Infios Dev Portal - Case 06 (Dozzle, Docker Compose and persistence) - demonstration
#
# PHASE=before: docker-compose-dozzle.yml as committed (Git HEAD).
# PHASE=after : docker-compose-dozzle.yml from the working tree (with the /data volume).
# Everything else is identical.
#
# Finding A (orphan containers warning), read only:
#   docker compose --dry-run ... up -d with the real Dozzle compose file and the real
#   project. Dry run prints the warning without creating, starting or removing anything.
# Finding B (Dozzle /data persistence), on a TEMPORARY copy:
#   starts the real Dozzle image from that compose file in its own project
#   (infios-caso06-<phase>, no published port), stores ONE test setting (a webhook
#   destination named infios-caso06-test, never triggered), runs the same down/up
#   cycle as .workspaceScripts/task_dozzle.sh, and checks whether the setting survived.
#   It also checks that Dozzle still lists containers and streams logs.
#
# Safety: the running Dev Portal containers, volumes and networks are not touched;
# only infios-caso06-<phase>* resources are created, and they are removed on exit.
# =============================================================================
set -uo pipefail

PHASE="after"
REPO="${REPO:-/workspaces/dev-portal}"
FILE_REL="docker-compose-dozzle.yml"
PROJECT="infios-caso06-${PHASE}"
HELPER_IMAGE="${HELPER_IMAGE:-dev-portal-dev-portal-admin-ui:latest}"   # any local image with node
WORK="$(mktemp -d "/tmp/${PROJECT}.XXXXXX")"
RESULTS=()

say()  { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
note() { printf '    %s\n' "$*"; }
code() { sed 's/^/      | /'; }
result() {  # result <PASS|FAIL|NOT VERIFIED|EXPECTED> <check> <detail>
  local c='1;32'; [ "$1" = FAIL ] && c='1;31'; [ "$1" = "NOT VERIFIED" ] && c='1;33'; [ "$1" = EXPECTED ] && c='1;36'
  printf "    \033[${c}m%-12s\033[0m %s (%s)\n" "$1" "$2" "$3"; RESULTS+=("$1|$2")
}
snapshot() {  # real environment, ignoring this demo's own resources
  { docker ps -a --format '{{.ID}} {{.Names}} {{.State}} {{.CreatedAt}}' | grep -v infios-caso06 | sort
    docker volume ls -q | grep -v infios-caso06 | sort; docker network ls -q | sort
    git -C "$REPO" status --porcelain; git -C "$REPO" diff | sha256sum; } 2>/dev/null
}
tmpc() {  # docker compose for the temporary copy (own project, no published port)
  docker compose -p "$PROJECT" --project-directory "$REPO" -f "$WORK/compose.yml" -f "$WORK/override.yml" "$@"
}
api() {  # api <method> <path> [json body]: HTTP call to the temporary Dozzle from a helper container
  docker run --rm -i --network "${PROJECT}_default" --entrypoint node "$HELPER_IMAGE" - "$@" <<'JS' 2>&1
const http = require('http'); const [method, path, body] = process.argv.slice(2);
const req = http.request({ host: 'k1-dozzle', port: 8080, method, path, headers: { 'content-type': 'application/json' } },
  res => { let b = ''; res.on('data', d => b += d); res.on('end', () => console.log(res.statusCode + ' ' + b)); });
req.on('error', e => console.log('000 ' + e.message)); if (body) req.write(body); req.end();
JS
}
cleanup() {
  tmpc down -v >/dev/null 2>&1    # temporary project only; -v removes only its own volume
  rm -rf "$WORK"
}
trap cleanup EXIT

# --- Step 0 ------------------------------------------------------------------------
say "Step 0 ($PHASE): preconditions"
command -v docker >/dev/null || { echo "docker not available"; exit 2; }
[ -z "$(docker ps -aq --filter "name=^${PROJECT}")" ] || { echo "resources named $PROJECT already exist; remove them first"; exit 2; }
if [ "$PHASE" = before ]; then git -C "$REPO" show "HEAD:$FILE_REL" > "$WORK/compose.yml" || exit 2; SRC="Git HEAD"
else cp "$REPO/$FILE_REL" "$WORK/compose.yml"; SRC="working tree"; fi
note "Compose file used: $FILE_REL from the $SRC"
cat -n "$WORK/compose.yml" | code
snapshot > "$WORK/env-start.txt"

# --- Finding A: orphan containers warning ----------------------------------------------
say "Finding A: why Docker Compose reports orphan containers"
note "Project name: .env:$(grep -n '^COMPOSE_PROJECT_NAME=' "$REPO/.env" | head -1)  (every compose file run from the repo uses it)"
PNAME="$(docker compose --project-directory "$REPO" -f "$WORK/compose.yml" config 2>/dev/null | sed -n 's/^name: //p')"
note "Project Docker Compose resolves for the Dozzle file: $PNAME"
SERVICES="$(docker compose --project-directory "$REPO" -f "$WORK/compose.yml" config --services 2>/dev/null | tr '\n' ' ')"
note "Services in the Dozzle file: $SERVICES"
note "Containers that already belong to project '$PNAME' (label com.docker.compose.project), with the file that created them:"
docker ps -a --filter "label=com.docker.compose.project=$PNAME" \
  --format '{{.Names}}|{{.Label "com.docker.compose.service"}}|{{.Label "com.docker.compose.project.config_files"}}' \
  | sed "s#$REPO/##" | sort > "$WORK/project-containers.txt"
sed 's/|/  service=/; s/|/  file=/' "$WORK/project-containers.txt" | code
note "Command (dry run, changes nothing): docker compose --dry-run -f $FILE_REL up -d"
docker compose --dry-run --project-directory "$REPO" -f "$WORK/compose.yml" up -d > "$WORK/dryrun.txt" 2>&1
grep -o 'Found orphan containers.*' "$WORK/dryrun.txt" | cut -c1-260 | code
ORPHANS="$(grep -o -E 'Found orphan containers \(([^)]*)\)' "$WORK/dryrun.txt" | sed -E 's/.*\((.*)\)/\1/; s/, /\n/g' | sort | tr '\n' ' ')"
EXPECTED="$(while IFS='|' read -r n s f; do case " $SERVICES " in *" $s "*) ;; *) echo "$n";; esac; done < "$WORK/project-containers.txt" | sort | tr '\n' ' ')"
if [ -z "$ORPHANS" ] && [ -z "$EXPECTED" ]; then
  result "NOT VERIFIED" "orphan warning" "no other containers in project $PNAME right now, so there is nothing to report"
elif [ "$ORPHANS" = "$EXPECTED" ]; then
  result EXPECTED "orphan warning = containers of project '$PNAME' whose service is not in $FILE_REL" "$(echo $ORPHANS | wc -w) containers"
else
  result FAIL "orphan warning does not match the project's containers" "warned: ${ORPHANS:-none} / expected: ${EXPECTED:-none}"
fi
snapshot > "$WORK/env-after-a.txt"
cmp -s "$WORK/env-start.txt" "$WORK/env-after-a.txt" && result PASS "dry run left containers, volumes and networks unchanged" "snapshot equal" \
  || result FAIL "dry run changed the environment" "see diff"

# --- Finding B: Dozzle /data persistence (temporary copy) -------------------------------
say "Finding B: does Dozzle keep its /data settings across the task's down/up cycle?"
note "The task does: .workspaceScripts/task_dozzle.sh:$(grep -n 'up --abort-on-container-exit' "$REPO/.workspaceScripts/task_dozzle.sh" | cut -d: -f1) up, then :$(grep -n 'down >/dev/null' "$REPO/.workspaceScripts/task_dozzle.sh" | cut -d: -f1) down (removes the container)."
if ! docker image inspect "$HELPER_IMAGE" >/dev/null 2>&1; then
  result "NOT VERIFIED" "persistence" "helper image $HELPER_IMAGE not found; set HELPER_IMAGE to a local image with node"
else
  printf 'services:\n  k1-dozzle:\n    ports: !reset []\n' > "$WORK/override.yml"   # only removes the published port
  tmpc up -d >/dev/null 2>&1 || { result FAIL "temporary Dozzle start" "compose up failed"; exit 1; }
  sleep 4
  CID="$(tmpc ps -q k1-dozzle)"
  note "Temporary Dozzle: $(docker inspect -f '{{.Name}} image={{.Config.Image}}' "$CID") version $(api GET /api/version | sed -E 's/^200 //; s/<[^>]*>//g' | head -c 40)"
  MOUNT="$(docker inspect -f '{{range .Mounts}}{{if eq .Destination "/data"}}{{.Type}}:{{.Name}}{{end}}{{end}}' "$CID")"
  [ -n "$MOUNT" ] && result PASS "/data is mounted" "$MOUNT" || result FAIL "/data is mounted" "no mount: /data lives in the container's own layer"
  DP="$(api GET /api/setup | grep -o '"dataPersisted":[a-z]*' | cut -d: -f2)"
  [ "$DP" = true ] && result PASS "Dozzle reports dataPersisted" "true" || result FAIL "Dozzle reports dataPersisted" "${DP:-unknown}"
  ADD="$(api POST /api/notifications/dispatchers '{"type":"webhook","name":"infios-caso06-test","url":"http://127.0.0.1:9/infios-caso06-test"}')"
  note "Test setting stored: HTTP ${ADD%% *} (webhook destination 'infios-caso06-test', never triggered)"
  note "Files Dozzle wrote in /data: $(docker cp "$CID:/data" - 2>/dev/null | tar -t 2>/dev/null | tr '\n' ' ')"
  note "Same cycle as the task: docker compose down, then up"
  tmpc down >/dev/null 2>&1; tmpc up -d >/dev/null 2>&1; sleep 4
  CID2="$(tmpc ps -q k1-dozzle)"
  note "Container recreated: $( [ "$CID" != "$CID2" ] && echo "yes (${CID:0:12} -> ${CID2:0:12})" || echo no)"
  LIST="$(api GET /api/notifications/dispatchers)"
  if [ "${ADD%% *}" != 201 ]; then result "NOT VERIFIED" "setting survives down/up" "test setting could not be stored"
  elif echo "$LIST" | grep -q 'infios-caso06-test'; then result PASS "setting survives down/up" "test destination still listed"
  else result FAIL "setting survives down/up" "lost: Dozzle lists ${LIST#* }"; fi
  # Dozzle still does its job: list containers and stream one container's logs (its own).
  docker run --rm -i --network "${PROJECT}_default" --entrypoint node "$HELPER_IMAGE" - "${CID2:0:12}" > "$WORK/logs.txt" 2>&1 <<'JS'
const http = require('http'); const id = process.argv[2];
const ev = http.get('http://k1-dozzle:8080/api/events/stream', res => { let b = '';
  res.on('data', d => { b += d; const m = b.match(/event: containers-changed\ndata: (.*)\n/); if (!m) return; ev.destroy();
    const list = JSON.parse(m[1]); const me = list.find(c => c.id === id);
    console.log('CONTAINERS ' + list.length); if (!me) { console.log('SELF missing'); return; }
    const lg = http.request({ host: 'k1-dozzle', port: 8080, method: 'POST', path: '/api/containers/logs',
      headers: { 'content-type': 'application/x-www-form-urlencoded' } }, r => { let t = '';
      r.on('data', d => t += d); r.on('end', () => console.log(/Accepting connections/.test(t) ? 'LOGS ok ' + r.statusCode : 'LOGS missing ' + r.statusCode)); });
    lg.end(`container=${me.host}/${id}&stdout=1&stderr=1`); }); });
setTimeout(() => process.exit(0), 8000);
JS
  N="$(sed -n 's/^CONTAINERS //p' "$WORK/logs.txt")"
  [ "${N:-0}" -gt 0 ] && result PASS "Dozzle lists containers" "$N containers" || result FAIL "Dozzle lists containers" "$(head -1 "$WORK/logs.txt")"
  grep -q '^LOGS ok' "$WORK/logs.txt" && result PASS "Dozzle streams container logs" "its own log line 'Accepting connections'" \
    || result FAIL "Dozzle streams container logs" "$(tail -1 "$WORK/logs.txt")"
fi

# --- Result ---------------------------------------------------------------------------------
say "Result"
tmpc down -v >/dev/null 2>&1
LEFT="$(docker ps -aq --filter "name=^${PROJECT}")$(docker volume ls -q --filter "name=^${PROJECT}")$(docker network ls -q --filter "name=^${PROJECT}")"
[ -z "$LEFT" ] && result PASS "temporary resources removed" "none left" || result FAIL "temporary resources removed" "$LEFT"
snapshot > "$WORK/env-end.txt"
cmp -s "$WORK/env-start.txt" "$WORK/env-end.txt" && result PASS "real environment unchanged" "containers, volumes, networks, Git" \
  || { result FAIL "real environment unchanged" "see diff"; diff "$WORK/env-start.txt" "$WORK/env-end.txt" | code; }
has() { printf '%s\n' "${RESULTS[@]}" | grep -q -F "$1|$2"; }
if [ "$PHASE" = before ]; then
  if has FAIL "/data is mounted" && has FAIL "setting survives down/up" && has PASS "real environment unchanged"; then
    printf '\n\033[1;31mBEFORE RESULT: Finding B reproduced - /data has no volume, so a Dozzle setting is lost when the task\n'
    printf 'removes the container. Finding A is expected Compose behaviour (shared project), not an error.\033[0m\n'; exit 0
  fi
  printf '\n\033[1;33mBEFORE RESULT: the persistence defect could NOT be reproduced (see the checks above).\033[0m\n'; exit 1
fi
if ! printf '%s\n' "${RESULTS[@]}" | grep -q '^FAIL|'; then
  printf '\n\033[1;32mAFTER RESULT: /data is on a named volume, the setting survives the down/up cycle, and Dozzle still\n'
  printf 'lists containers and streams logs. Finding A is unchanged by design (expected warning, documented).\033[0m\n'; exit 0
fi
printf '\n\033[1;31mAFTER RESULT: at least one check FAILED (see above).\033[0m\n'; exit 1
